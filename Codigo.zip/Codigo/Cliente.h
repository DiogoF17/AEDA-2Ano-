#ifndef PROJ1_CLIENTE_H
#define PROJ1_CLIENTE_H

#include <string>
#include <vector>
#include <iostream>
#include <algorithm>
#include <iomanip>

using namespace std;

/**
 * separa os ids dos pacotes transformando em vetor
 * @param ids string de ids passada
 * @return vetor de ids retornado
 */
vector<int> splitIds(string ids);

/**
 * retira os espacos a mais e coloca em carateres grandes o necessario
 * @param nome nome a formatar
 */
void formataNome(string &nome);

/**
 * classe que contem informacao sobre os clientes
 */
class Cliente {
    /**
     * diz qual o nome do cliente
     */
    string nome;
    /**
     * diz qual o nif do cliente
     */
    int nif;
    /**
     * diz quais os ids das habitacoes que adquiriu
     */
    vector<int> ids;
public:
    /**
     * construtor por omissao da classe cliente
     */
    Cliente(){}
    /**
     * construtor da classe cliente
     */
    Cliente(string n):nome(n){}
    /**
     * altera o nome do cliente
     * @param n nome que e para ficar
     */
    void setNome(string n) ;
    /**
     * altera o nif do cliente
     * @param n nif que e para ficar
     */
    void setNif(string n);
    /**
     * altera os ids das habitacoes
     * @param ids ids que sao para ficar
     */
    void setIds(string ids);
    /**
     * retorna o nome do cliente
     * @return nome do cliente
     */
    string getNome() const;
    /**
     * retorna o nif do cliente
     * @return nif do cliente
     */
    int getNif() const;
    /**
     * retorna os ids das habitacoes
     * @return ids das habitacoes ods clientes
     */
    vector<int> getIds() const;
    /**
     * associa uma habitcao com o id indicado ao cliente
     * @param id id da habitacao a associar
     */
    void assocHabit(int id);
    /**
     * desassocia uma habitacao indicada com o id do cliente
     * @param id id da habitacao a desassociar
     */
    void desassociarHabit(int id);
    /**
     * diz se ja rxiste uma habitacao com aquele id
     * @param id id a verificar
     * @return verdade se ja existe e falso se nao existe
     */
    bool existe(int id);
    /**
     * pergunta ao utilizador qual o id do pacote a pagar
     * @return o id do pacote a pagar
     */
    int pagarMen();
    /**
     * mostra o cliente
     */
    void imprime() const;
    /**
     * diz se um cliente e igual a outro
     * @param c cliente a comparar
     * @return verdade se sao iguais falso caso contrario
     */
    bool operator==(const Cliente &c);
    /**
     * diz quando um cliete e menor que outro
     * @param c cliente a comparar
     * @return verdade se for menor que o usado no param c
     */
    bool operator<(const Cliente &c);
};


#endif //PROJ1_CLIENTE_H
