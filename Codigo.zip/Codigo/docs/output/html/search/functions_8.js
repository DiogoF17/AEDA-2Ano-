var searchData=
[
  ['operator_3c_179',['operator&lt;',['../class_cliente.html#a970f9c11e1c32269c9ae80c1d5be90f7',1,'Cliente']]],
  ['operator_3d_3d_180',['operator==',['../class_cliente.html#ad18df5bc5519b81b1967ce8992d7d947',1,'Cliente']]]
];
