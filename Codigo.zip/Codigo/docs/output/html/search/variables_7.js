var searchData=
[
  ['nif_235',['nif',['../class_cliente.html#a6ca09f247e4f13ef51251bba0bc6654c',1,'Cliente']]],
  ['nome_236',['nome',['../class_cliente.html#a7ebd7f8e396e9fd8b9c1f5fc20a16fed',1,'Cliente']]],
  ['nomeficheiro_237',['nomeFicheiro',['../class_condominio.html#ad6061cfb17a7efbb9b5cf03395963c13',1,'Condominio']]],
  ['num_5focorrencias_238',['num_ocorrencias',['../class_servicos.html#a905a5d7a5cb22559cf0744605d5d1451',1,'Servicos']]]
];
