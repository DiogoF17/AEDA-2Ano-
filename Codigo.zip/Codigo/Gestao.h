//
// Created by Utilizador on 07-12-2019.
//

#ifndef PROJ1_GESTAO_H
#define PROJ1_GESTAO_H

#include "bst.h"
#include "Condominio.h"
#include <ctime>

using namespace std;

/**
 * imprime a tabela dos condominios
 */
void tabCond();

/**
 * classe auxiliar serve apenas para usar na bst
 */
class Aux{
public:
    /**
     * apontador para um condominio
     */
    Condominio *c;
    /**
     * construtor da classe condominio
     * @param a condominio para para colocar em c
     */
    Aux(Condominio *a): c(a){};
    /**
     * definicao do operador < para a classe aux
     * @param a classe a comparar
     * @return retorna se uma classe e menor que outra
     */
    bool operator<(const Aux &a) const{
        if(c->getHab() != a.c->getHab())
            return c->getHab() < a.c->getHab();
        else if(c->getViv() != a.c->getViv())
            return c->getViv() < a.c->getViv();
        else if(c->getLocalizacao() != a.c->getLocalizacao())
            return c->getLocalizacao() < a.c->getLocalizacao();
        else
            return c->getNome() < a.c->getNome();
    }
};

/**
 * classe responsavel gestao dos condominios
 */
class Gestao {
    /**
     * constem os condominios
     */
    BST<Aux> gestao;
    /**
     * variavel que diz se e necessario atualizar o ficheiro da gestao
     */
    bool updateCond = false;
public:
    /**
     * construtor da classe gestao
     */
    Gestao():gestao(new Condominio()){};
    /**
     * destrutor da classe gestao
     */
    ~Gestao(){
        BSTItrLevel<Aux> it(gestao);
        while(!it.isAtEnd()){
            delete it.retrieve().c;
            it.advance();
        }
    }
    /**
     * le o ficheiro da gestao dos condominios "gestao.txt"
     */
    void readFile();
    /**
     * serve para escolhermos o condominio sobre o qual vamos atuar
     * @param op informa se devemos remover o condominio da bst ou nao
     * @return o condominio escolhido pelo utilizador
     */
    Condominio* escolheCondominio(int op);
    /**
     * insere um condominio na bst
     * @param c condominio a inserir
     */
    void insereCond(Condominio *c);
    /**
     * imprime todos os condominios
     */
    void imprime();
    /**
     * atualiza o ficheiro "gestao.txt"
     */
    void writeFile();
    /**
     * verifica se e necessario atualizar o ficheiro
     * @return true caso seja necessario e false caso contrario
     */
    bool checkUpdate() const;
    /**
     * verifica se existe um condominio com aquele nome
     * @param nome nome a procurar
     * @return retorna true caso exista e false caso contrario
     */
    bool findNome(string nome) const;
    /**
     * cria um condominio
     */
    void criaCond();
    /**
     * altera um condominio
     * @param c condominio a alterar
     */
    void altCond(Condominio *c);
    /**
     * remove um condominio
     */
    void remCond();
    /**
     * mostra um condominio especifico
     * @param nome nome do condominio a ver
     */
    void verCondEsp(string nome) const;
    /**
     * mostra todos os condominios
     * @param op se tiver a 0 e por ordem crescente de habitacoes se nao e por ordem decrescente
     */
    void verTodosCond(int op);
};


#endif //PROJ1_GESTAO_H
