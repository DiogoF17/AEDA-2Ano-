//
// Created by Utilizador on 07-12-2019.
//

#ifndef PROJ1_GESTAO_H
#define PROJ1_GESTAO_H

#include "bst.h"
#include "Condominio.h"

class Gestao {
    BST<Condominio*> gestao;
    bool updateCond = false;
public:
    Gestao():gestao(new Condominio()){};
    void readFile();
    Condominio* escolheCondominio(int op);
    void insereCond(Condominio *c);
    void imprime();
    void writeFile();
    bool checkUpdate() const;
};


#endif //PROJ1_GESTAO_H
