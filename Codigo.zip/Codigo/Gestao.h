//
// Created by Utilizador on 07-12-2019.
//

#ifndef PROJ1_GESTAO_H
#define PROJ1_GESTAO_H

#include "bst.h"
#include "Condominio.h"

using namespace std;

class Aux{
public:
    Condominio *c;
    Aux(Condominio *a): c(a){};
    bool operator<(const Aux &a) const{
        if(c->getHab() != a.c->getHab())
            return c->getHab() < a.c->getHab();
        else if(c->getViv() != a.c->getViv())
            return c->getViv() < a.c->getViv();
        else if(c->getLocalizacao() != a.c->getLocalizacao())
            return c->getLocalizacao() < a.c->getLocalizacao();
        else
            return c->getNome() < a.c->getNome();
    }
};

class Gestao {
    BST<Aux> gestao;
    bool updateCond = false;
public:
    Gestao():gestao(new Condominio()){};
    ~Gestao(){
        BSTItrLevel<Aux> it(gestao);
        while(!it.isAtEnd()){
            delete it.retrieve().c;
            it.advance();
        }
    }
    void readFile();
    Condominio* escolheCondominio(int op);
    void insereCond(Condominio *c);
    void imprime();
    void writeFile();
    bool checkUpdate() const;
    bool findNome(string nome) const;
    void criaCond();
    void altCond(Condominio *c);
    void remCond();
    void verCondEsp(string nome) const;
};


#endif //PROJ1_GESTAO_H
