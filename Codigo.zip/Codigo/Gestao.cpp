//
// Created by Utilizador on 07-12-2019.
//

#include "Gestao.h"
#include <fstream>

void tabCond(){
    cout << "-------------------------------------------------------------------------\n";
    cout << right << setw(35) << "CONDOMINIOS\n";
    cout << "-------------------------------------------------------------------------\n";
    cout << left << setw(30) << "Nome"
         << " " <<  setw(20) << "Localizacao"
         << " " << setw(10) << "Num Hab"
         << " " << setw(10) << "Num Viv";
    cout << "\n-------------------------------------------------------------------------\n";
}

void Gestao::readFile(){
    string aux;
    ifstream entrada;
    entrada.open("gestao.txt");
    getline(entrada, aux); //le a palavra gestao
    while(getline(entrada, aux)){
        Condominio *c = new Condominio();
        c->setNome(aux);
        getline(entrada, aux); c->setLocalizacao(aux);
        getline(entrada, aux);  c->setFileName(aux);
        getline(entrada, aux);  c->setRegiFileName(aux);
        c->readFile();
        gestao.insert(c);
    }
}

void Gestao::imprime(){
    BSTItrIn<Condominio*> it(gestao);
    while(!it.isAtEnd()){
        cout << left << setw(30) << it.retrieve()->getNome()
             << " " <<  setw(20) << it.retrieve()->getLocalizacao()
             << " " << setw(10) << it.retrieve()->getHab()
             << " " << setw(10) << it.retrieve()->getViv() << endl;
        it.advance();
    }
    cout << "-------------------------------------------------------------------------\n";
}

Condominio* Gestao::escolheCondominio(int op){
    string nome;
    cout << "Sobre qual condominio pretende efetuar a operacao? "; cin.ignore(1000, '\n');getline(cin, nome);
    cout << endl;
    formataNome(nome);
    Condominio *c;
    BSTItrIn<Condominio*> it(gestao);
    while(!it.isAtEnd()){
        if(it.retrieve()->getNome() == nome){
            c = it.retrieve();
            if(op == 0)
                gestao.remove(it.retrieve());
            return c;
        }
        it.advance();
    }
    throw runtime_error("Nao existe o condominio: " + nome);
}

void Gestao::insereCond(Condominio *c){
    gestao.insert(c);
}

bool Gestao::checkUpdate() const {
    BSTItrIn<Condominio*> it(gestao);
    while(!it.isAtEnd()){
        if(it.retrieve()->update)
            return true;
        it.advance();
    }
    return false;
}

void Gestao::writeFile() {
    char res;
    if(checkUpdate() || updateCond){
        std::cout << "\n=========================================================\n";
        std::cout << "Pretende guardar as alteracoes efetuadas('s'\\'n'): ", std::cin >> res;
        while(std::cin.fail() || (res!= 's' && res!='n')){
            if(std::cin.fail()){
                std::cin.clear();
                std::cin.ignore(1000, '\n');
            }
            std::cout << "Erro! Pretende guardar as alteracoes efetuadas('s'\\'n'): ", std::cin >> res;
        }
        if(res =='s') {
            BSTItrIn<Condominio *> it(gestao), it1(gestao);
            ofstream saida("gestao.txt");
            saida << "GESTAO";
            while(!it1.isAtEnd()){
                saida << endl << it1.retrieve()->getNome();
                saida << endl << it1.retrieve()->getLocalizacao();
                saida << endl << it1.retrieve()->getFileName();
                saida << endl << it1.retrieve()->getRegiFileName();
                it1.advance();
            }
            saida.close();
            while(!it.isAtEnd()){
                it.retrieve()->writeFile();
                it.advance();
            }
        }
        cout << "\nAs alteracoes foram gravadas com sucesso!\n\n";
    }
    exit(1);
}

