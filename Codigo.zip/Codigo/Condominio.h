#ifndef PROJ1_CONDOMINIO_H
#define PROJ1_CONDOMINIO_H

#include <vector>
#include "Cliente.h"
#include "Habitacao.h"
#include "Servicos.h"
#include <iostream>
#include <algorithm>
#include <iomanip>

using namespace std;

/**
 * verifica se uma determinada opcao e valida
 * @param zero diz se devemos contabilizar o zero como sendo opcao valida
 * @param num numero de opcoes validas
 * @return opcao valida do utilizador
 */
int Opcao(bool zero, int num);

/**
 * imprime o formato da tabela para os clientes
 */
void tabelaCliente();

/**
 * imprime o formato da tabela para os servicos
 */
void tabelaServicos();

/**
 * imprime o formato da tabela para os apartamentos
 */
void tabelaApartamentos();

/**
 * imprime o formato da tabela para as vivendas
 */
void tabelaVivendas();

/**
 * classe que contem toda a informacao do condominio
 */
class Condominio {
    /**
     * contem o nome do condominio
     */
    string nome;
    /**
     * contem a localizacao do condominio
     */
    string localizacao;
    /**
     * vetor que contem as habitacoes do condominio
     */
    vector<Habitacao*> habitacoes;
    /**
     * vetor que guarda os clientes do condominio
     */
    vector<Cliente> clientes;
    /**
     * vetor que guarda os servicos do condominio
     */
    vector<Servicos> servicos;
    /**
     * numero da Habitacoes do condominio
     */
    int numHab = 0;
    /**
     * numero de vivendas do condominio
     */
    int numViv = 0;
    /**
     * nome do ficheiro do condominio
     */
    string fileName;
    /**
     * nome do ficheiro do condominio do registo dos servicos do clientes
     */
    string registofile;
public:
    /**
     * retorna o nome do ficheiro
     * @return nome do ficheiro
     */
    string getFileName() const;
    /**
    * retorna o nome do ficheiro do registo dos servicos
     * @return nome do ficheiro do registo dos servicos
     */
    string getRegiFileName() const;
    /**
     * altera o nome do ficheiro
     */
    void setFileName(string f);
    /**
     * altera o nome do ficheiro do registo dos servicos
     */
    void setRegiFileName(string f);
    /**
     * variavel que dis se e preciso atualizar o ficheiro
     */
    bool update;
    /**
     * construtor por omissao da classe condominio
     */
    Condominio(){nome = "", localizacao = "";}
    /**
     * destrutor da classe condominio
     */
    ~Condominio(){
        for(vector<Habitacao*>::iterator it = habitacoes.begin(); it != habitacoes.end(); it++)
            delete *it;
    }
    /**
     * imprime todos os clientes do condominio
     * @param op qual o tipo de ordenacao(se for 0 normal, se for 1 por nome)
     */
    void imprimeTodosClientes(int op) const;
    /**
     * imprime um cliente especificado pelo utilizador dentro desta funcao
     */
    void imprimeCliente() const;
    /**
     * mostra todas as habitacoes
     * @param op qual o tipo de ordenacao(se for 0 normal, se for 1 por id, se for 2 por area habitacional)
     */
    void verTodosHabitacoes(int op) const;
    /**
     * mostra uma habitacao especificada pelo utilizador dentro desta funcao
     */
    void verHabitacaoEsp()const;
    /**
     * le o ficheiro
     * @param aux nome do ficheiro do condominio
     */
    void readFile();
    /**
     * escreve no ficheiro se for necessario
     */
    void writeFile();
    /**
     * adiciona cliente aos clientes do condominio
     * @param c cliente que e para adicionar
     */
    void addCliente(Cliente &c);
    /**
     * altera um cliente especificado pelo utilizador dentro desta funcao
     */
    void alterarCliente();
    /**
     * remove um cliente especificado pelo utilizadpor dentro desta funcao
     */
    void removerCliente();
    /**
     * adquire uma habitacao para um determinado cliente especificado dentro desta funcao
     */
    void associarHabit();
    /**
     * desassocie uma habitacao que um determinado cliente comprou
     */
    void desassociarHabit();
    /**
     * adiciona habitacao as habitaoes do condominio
     * @param h habitacao que e para adicionar
     */
    void addHabitacao(Habitacao *h);
    /**
     * altera uma habitacao especificada pelo utilizador dentro desta funcao
     */
    void alterarHabitacao();
    /**
     * remove uma habitacao existente neste condominio especificada pelo utilizadpor dentro desta funcao
     */
    void removerHabitacao();
    /**
     * verifica se um determinado id ja existe em alguma habitacao se sim lanca excecao
     * @param id id a verificar
     */
    void verifyId(int id);
    /**
     * verifica se um determinado cliente ja possui aquele nif se sim lanca excecao
     */
    void verifyNif(string &nif);
    /**
     * paga uma determinada mensalidade de uma habitacao de um determinado cliente especificado dentro desta funcao
     */
    void pagar();
    /**
     * imprime todos os apartamentos
     */
    void imprimeApartamentos();
    /**
     * imprime todas as vivendas
     */
    void imprimeVivendas();
    /**
     * mostra o lucro do condominio com base nas mensalidades
     */
    void verLucMen();
    /**
     * mostra as despesas do condominio
     */
    void verDesp();
    /**
    * adiciona um servico aos servicos do condominio
    * @param c servico que e para adicionar
    * @param indice indice do servico limpeza que pretende remover
    */
    void addServico(Servicos &c,int indice);
    /***
     * altera o servico pretendido pelo utilizador
     */
    void alterarServico();
    /**
     * remove o servico pretendido pelo utilizador
     * @param indice indice do servico limpeza que pretende remover
     */
    void removerServico(int &indice);
    /**
     * inicia um servico
     */
    void iniciarServico();
    /**
     * cancela um servico
     */
    void cancelServico();
    /**
     * terminar um servico
     */
    void terminarServico();
    /**
     * imprime todos os servicos
     */
    void imprimeTodosServicos();
    /**
     * imprime todos os servicos por estado("a decorrer","cancelados","terminados")
     * @param op vai de 1 a 3 que representa 1="a decorrer", 2="cancelados", 3="terminados"
     */
    void imprimeServicosPorEstado(int op);
    /**
     * imprime todos os servicos prestados numa habitacao
     */
    void imprimeServicosHabitacao();
    /**
     * imprime todos os servicos prestados a um cliente
     */
    void imprimeServicosCliente();
    /**
     * imprime todos os servicos do condominio por ordem cronologica
     */
    void imprimeServicosOrdemCrono();
    /**
     * verifica se os parametros necessarios para criar um servico sao aceites
     * @param servico tipo de servico que o prestador realiza
     * @param preco preco mensal que o prestador cobra pelo servico
     * @param prestador autoridade responsavel pelo servico
     * @param limpeza identifica se é autorizada a criacao de um servico do tipo limpeza
     */
    void verifyServico(string &servico,float &preco,const string &prestador,bool limpeza);
    /**
     * altera o nomde do condominio
     * @param n nome para alterar
     */
    void setNome(string n);
/**
 *  altera a localizacao do condominio
 * @param l localizacao a alterar
 */
    void setLocalizacao(string l);
    /**
     * define o operador < da classe condominio
     * @param c condominio a comparar
     * @return retorna true se um condominio tiver menos habitacoes que outro ou se tiver menos vivendas
     */
    bool operator<(const Condominio &c) const;
    /**
     * retorna nome do condominio
     * @return nome do condominio
     */
    string getNome() const;
    /**
     * retorna localizacao
     * @return localizacao
     */
    string getLocalizacao() const;
    /**
     * retorna o numero de habitacoes
     * @return numero de habitacoes
     */
    int getHab() const;
    /**
     * retorna numero de vivendas
     * @return numero de vivendas
     */
    int getViv() const;
};


#endif //PROJ1_CONDOMINIO_H
