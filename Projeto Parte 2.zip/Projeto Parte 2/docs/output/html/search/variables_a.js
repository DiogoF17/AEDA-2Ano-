var searchData=
[
  ['nif_373',['nif',['../class_cliente.html#a6ca09f247e4f13ef51251bba0bc6654c',1,'Cliente']]],
  ['nome_374',['nome',['../class_cliente.html#a7ebd7f8e396e9fd8b9c1f5fc20a16fed',1,'Cliente::nome()'],['../class_condominio.html#a4319c0513d0df2d77d7960ffe7d52aa1',1,'Condominio::nome()']]],
  ['num_5focorrencias_375',['num_ocorrencias',['../class_servicos.html#a905a5d7a5cb22559cf0744605d5d1451',1,'Servicos']]],
  ['numhab_376',['numHab',['../class_condominio.html#ab16e994323b9b29662d42e7eb6130d29',1,'Condominio']]],
  ['numviv_377',['numViv',['../class_condominio.html#a5910397e7eaa2a23d8de0167091e884a',1,'Condominio']]]
];
