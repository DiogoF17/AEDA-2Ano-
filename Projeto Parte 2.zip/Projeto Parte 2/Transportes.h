//
// Created by Marcelo on 23/12/2019.
//

#ifndef PROJ1_TRANSPORTES_H
#define PROJ1_TRANSPORTES_H

#include <string>
#include <ctime>
#include <vector>
#include <queue>
#include <iomanip>
#include <iostream>


using namespace std;


struct Paragem{
    /**
     * nome do local de paragem
     */
    string local;
    /**
     * tempo(min) de espera nesta paragem
     */
    int tempo;
    /**
     * indica se esta paragem esta ativa (=true) ou nao (=false)
     */
    bool ativa;
};


class Transportes {

public:
    /**
     * contrutor por omissao da classe tranportes
     */
    Transportes(){};
    /**
     * contrutor da classe Transportes
     * @param tipo tipo de transporte publico
     * @param destino destino do transporte publico
     * @param pontoMprox local de paragem mais proximo do condominio
     * @param pontosParagem pontos de paragem efetuados pelo transporte publico
     */
     Transportes(string tipo, string destino, string pontoMprox, vector<Paragem> pontosParagem);
     /**
      * retorna o tipo de transporte publico
      * @return tipo de transporte publico
      */
      string getTipo() const;
      /**
       * retorna o destino do transporte publico
       * @return destino do transporte publico
       */
      string getDestino() const;
      /**
       * retorna o local de paragem mais proximo do condominio
       * @return local de paragem mais proximo do condominio
       */
      string getPontoMaisProx() const;
      /**
       * retorna um vector com os pontos de paragem efecutados pelo transporte publico
       * @return locais de paragem efecuados pelo transporte publico
       */
      vector<Paragem> getPontosParagem() const;
      /**
       * retorna uma fila com os pontos de paragem que falam ate ao destino
       * @return pontos de paragem ate ao destino
       */
      queue<Paragem> getParagensToDestino() const;
      /**
       * altera o destino do transporte publico
       * @param destino novo destino do tranporte publico
       */
      void setDestino(string destino);
      /**
       * altera o tipo do transporte publico
       * @param t novo tipo de transporte
       */
      void setTipo(string t);
      /**
       * altera o ponto de paragem mais proximo do condominio
       * @param p novo ponto de paragem mais proximo do condominio
       */
      void setPontoMaisProx(string p);
      /**
       * altera os pontos de paragem do transporte publico
       * @param pp novo vetor com os novos ponto de paragem
       */
      void setPontosParagem(vector<Paragem> pp);
      /**
       * altera os pontos de paragem que faltam ate ao detino
       * @param ptd nova fila de pontos de paragem ate ao destino.
       */
      void setParagensToDestino(queue<Paragem> ptd);
      /**
       * altera o tempo que auxilia na deslocacao dos transportes publicos
       * @param tempo novo tempo base
       */
      void setTempoInicial(tm tempo);
      /**
       * operador menor da classe transportes
       * @param t1 transporte a comparar
       * @return true se t1 for maior que o transporte a comparar
       */
      bool operator <( const Transportes&t1) const ;
      /**
       * retorna o tempo necessario para que transporte chege ao condominio desde o seu ponto de partida
       * @return tempo para chegar ao condominio
       */
      int getTempoToCondominio() const;
      /**
       * altera o tempo necessario para que transporte chege ao condominio desde o seu ponto de partida
       * @param t novo tempo necessario
       */
      void setTempoToCondominio(int t);
      /**
       * imprime os dados do transporte
       */
       void imprime() const;
       /**
        * imprime todos os pontos de paragem no vetor
        */
       void imprimePontosParagem() const;
       /**
        * adiciona um novo ponto de paragem ao vetor de paragens do transporte
        * @param indice local onde deseja colocar o novo ponto de paragem
        */
       void adicionarPontoDeParagem(int indice);
       /**
        * verifica se a paragem existe no vetor de pontos de paragem
        * @param local nome do local da paragem
        * @return retorna true se encontrar, false caso contrario
        */
       bool verifyParagem(string local);
       /**
        * recalcula o tempo de viagem ate ao condominio
        */
       void recalcularTempo();
       /**
        * atualiza a fila de paragens ate ao destino do transporte
        */
       void atualizarParagensToDestino();
       /**
        * verifica se o transporte publico já tem todos os pontos de paragem ativos
        * @return true se tiver todos os pontos de paragem ativos, false caso contrario
        */
       bool verificarTodosAtivos() const ;
       /**
        *
        * @return
        */
       bool verificarTodosDesativos() const;
private:
    /**
     * tipo de transporte publico p.e: autocarro, metro, comboio,..
     */
     string tipo;
     /**
      * destino do tranporte publico
      */
     string destino;
     /**
      * localizacao do ponto de paragem mais proximo do condominio
      */
     string pontoMaisprox;
     /**
      * pontos de paragem do transporte publico
      */
     vector<Paragem> pontosParagem;
      /**
       * pontos de paragem que faltam até ao destino
       */
     queue<Paragem> paragensToDestino;
     /**
      * tempo(minutos) para que o transporte chegue ao condominio desde do seu ponto de partida
      */
     int tempoToCondominio;
     /**
      * tempo inicial utilizado para gerir a deslocacao dos transportes publicos
      */
     tm tempoDeInicio;
};


#endif //PROJ1_TRANSPORTES_H
