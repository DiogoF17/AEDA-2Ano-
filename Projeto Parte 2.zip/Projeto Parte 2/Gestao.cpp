//
// Created by Utilizador on 07-12-2019.
//

#include "Gestao.h"
#include <fstream>

void tabCond(){
    cout << "-------------------------------------------------------------------------\n";
    cout << right << setw(35) << "CONDOMINIOS\n";
    cout << "-------------------------------------------------------------------------\n";
    cout << left << setw(30) << "Nome"
         << " " <<  setw(20) << "Localizacao"
         << " " << setw(10) << "Num Hab"
         << " " << setw(10) << "Num Viv";
    cout << "\n-------------------------------------------------------------------------\n";
}

void Gestao::readFile(){
    string aux;
    ifstream entrada;
    entrada.open("gestao.txt");
    getline(entrada, aux); //le a palavra gestao
    while(getline(entrada, aux)){
        Condominio *c = new Condominio();
        c->setNome(aux);
        getline(entrada, aux); c->setLocalizacao(aux);
        getline(entrada, aux);  c->setFileName(aux);
        getline(entrada, aux);  c->setRegiFileName(aux);
        getline(entrada, aux);  c->setTranspFileName(aux);
        c->readFile();
        gestao.insert(Aux(c));
    }
}

void Gestao::imprime(){
    tabCond();
    BSTItrIn<Aux> it(gestao);
    while(!it.isAtEnd()){
        cout << left << setw(30) << it.retrieve().c->getNome()
             << " " <<  setw(20) << it.retrieve().c->getLocalizacao()
             << " " << setw(10) << it.retrieve().c->getHab()
             << " " << setw(10) << it.retrieve().c->getViv() << endl;
        it.advance();
    }
    cout << "-------------------------------------------------------------------------\n\n";
}

Condominio* Gestao::escolheCondominio(int op){
    string nome;
    imprime();
    cout << "Sobre qual condominio pretende efetuar a operacao? "; cin.ignore(1000, '\n');getline(cin, nome);
    cout << endl;
    formataNome(nome);
    Condominio *c;
    BSTItrIn<Aux> it(gestao);
    while(!it.isAtEnd()){
        if(it.retrieve().c->getNome() == nome){
            c = it.retrieve().c;
            if(op == 0)
                gestao.remove(it.retrieve());
            return c;
        }
        it.advance();
    }
    throw runtime_error("Nao existe o condominio: " + nome);
}

void Gestao::insereCond(Condominio *c){
    gestao.insert(Aux(c));
    updateCond = true;
}

bool Gestao::checkUpdate() const {
    BSTItrIn<Aux> it(gestao);
    while(!it.isAtEnd()){
        if(it.retrieve().c->update)
            return true;
        it.advance();
    }
    return false;
}

void Gestao::writeFile() {
    char res;
    if(checkUpdate() || updateCond){
        std::cout << "\n=========================================================\n";
        std::cout << "Pretende guardar as alteracoes efetuadas('s'\\'n'): ", std::cin >> res;
        while(std::cin.fail() || (res!= 's' && res!='n')){
            if(std::cin.fail()){
                std::cin.clear();
                std::cin.ignore(1000, '\n');
            }
            std::cout << "Erro! Pretende guardar as alteracoes efetuadas('s'\\'n'): ", std::cin >> res;
        }
        if(res =='s') {
            BSTItrIn<Aux> it(gestao), it1(gestao);
            ofstream saida("gestao.txt");
            saida << "GESTAO";
            while(!it1.isAtEnd()){
                saida << endl << it1.retrieve().c->getNome();
                saida << endl << it1.retrieve().c->getLocalizacao();
                saida << endl << it1.retrieve().c->getFileName();
                saida << endl << it1.retrieve().c->getRegiFileName();
                saida << endl << it1.retrieve().c->getTranspFileName();
                it1.advance();
            }
            saida.close();
            while(!it.isAtEnd()){
                it.retrieve().c->writeFile();
                it.advance();
            }
            cout << "\nAs alteracoes foram gravadas com sucesso!\n\n";
        }
    }
    exit(1);
}

bool Gestao::findNome(string nome) const{
    BSTItrIn<Aux> it(gestao);
    while(!it.isAtEnd()){
        if(it.retrieve().c->getNome() == nome)
            return true;
        it.advance();
    }
    return false;
}

void Gestao::verCondEsp(string nome) const {
    BSTItrIn<Aux> it(gestao);
    cout << "---------------------------------------------------------------------------------------\n";
    cout << "Condominio: " << nome << endl;
    while(!it.isAtEnd()){
        if(it.retrieve().c->getNome() == nome) {
            it.retrieve().c->imprimeTodosClientes(1);
            it.retrieve().c->verTodosHabitacoes(1);
            it.retrieve().c->imprimeTodosServicos();
            it.retrieve().c ->imprimeTodosAntigosClientes();
            break;
        }
        it.advance();
    }
}

void Gestao::criaCond(){
    string nome, aux;
    cin.ignore(1000, '\n');
    Condominio *c = new Condominio();
    cout << "Introduza o nome do condominio:"; getline(cin, nome);
    formataNome(nome);
    if(findNome(nome)) {
        delete c;
        throw runtime_error("\nJa existe um condominio com o nome: " + nome);
    }
    c->setNome(nome);
    cout << "Introduza a localizacao:"; getline(cin, aux);
    formataNome(aux); c->setLocalizacao(aux);
    cout << "Introduza o nome do ficheiro:"; getline(cin, aux); c->setFileName(aux);
    cout << "Introduza o nome do ficheiro onde pretende guardar a informacao do registo dos servicos:"; getline(cin, aux); c->setRegiFileName(aux);
    insereCond(c);
    cout << "\nCondominio criado com sucesso!\n\n";
    verCondEsp(nome);
}

void Gestao::altCond(Condominio *c) {
    int op;
    string aux;
    cout << "1) Nome; \n2) Localizacao;\n3) Nome do ficheiro; \n4) Nome do ficheiro dos registos dos servicos;";
    op = Opcao(false, 4);
    cin.ignore(1000, '\n');
    switch(op){
        case 1:
            cout << "\nIntroduza o novo nome:"; getline(cin, aux);
            formataNome(aux);
            if(findNome(aux))
                throw runtime_error("\nJa existe um condominio com esse nome!");
            c->setNome(aux);
            break;
        case 2:
            cout << "\nIntroduza a nova localizacao:"; getline(cin, aux);
            formataNome(aux);
            c->setLocalizacao(aux);
            break;
        case 3:
            cout << "\nIntroduza o novo nome do ficheiro:"; getline(cin, aux);
            c->setFileName(aux);
            break;
        case 4:
            cout << "\nIntroduza o novo nome do ficheiro do registo dos servicos:"; getline(cin, aux);
            c->setRegiFileName(aux);
            break;
    }
    insereCond(c);
    cout << "\nCondominio alterado com sucesso!\n";
    verCondEsp(c->getNome());
}

void Gestao::remCond(){
    escolheCondominio(0);
    updateCond = true;
    cout << "\nCondominio removido com sucesso!\n";
}

void Gestao::verTodosCond(int op){
    if(op == 0){
        BSTItrIn<Aux> it(gestao);
        while(!it.isAtEnd()){
            cout << "---------------------------------------------------------------------------------------\n";
            cout << "Condominio: " << it.retrieve().c->getNome() << endl;
            it.retrieve().c->imprimeTodosClientes(1);
            it.retrieve().c->verTodosHabitacoes(1);
            it.retrieve().c->imprimeTodosServicos();
            it.retrieve().c ->imprimeTodosAntigosClientes();
            system("pause");
            it.advance();
        }
    }
    else{
        BSTItrPost<Aux> it(gestao);
        while(!it.isAtEnd()){
            cout << "---------------------------------------------------------------------------------------\n";
            cout << "Condominio: " << it.retrieve().c->getNome() << endl;
            it.retrieve().c->imprimeTodosClientes(1);
            it.retrieve().c->verTodosHabitacoes(1);
            it.retrieve().c->imprimeTodosServicos();
            it.retrieve().c ->imprimeTodosAntigosClientes();
            system("pause");
            it.advance();
        }
    }
}

