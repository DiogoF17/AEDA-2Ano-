#include <iostream>
#include <fstream>
#include <vector>
#include "Condominio.h"
#include "Gestao.h"

using namespace std;

string delim = "\n=========================================================";

//------------------------------------------------------
//                      FUNCOES PRINCIPAIS
//-----------------------------------------------------

/**
 * cria novos pontos de paragem nos trajetos dos tranportes publicos de um condominio
 * @param c classe usada que e para ser alterada e usada ao longo do programa
 */
void criarPontosParagem(Gestao &g){
    cout << delim;
    cout << "\n\t\tCRIAR PONTOS DE PARAGEM";
    cout << delim << "\n\n";
    Condominio *c1;
    try {
        c1 = g.escolheCondominio(0);
        try {
            c1->recalcularTempoToCondominio();
            c1->addPontoDeParagem();
            c1->update = true;
            g.insereCond(c1);
        } catch (runtime_error &x) {
            g.insereCond(c1);
            cout << "\n" << x.what() << endl << endl;
        }
        catch (invalid_argument &x) {
            g.insereCond(c1);
            cout << x.what() << endl << endl;
        }
    } catch (runtime_error &x) {
        cout << "\n" << x.what() << endl << endl;
    }
    catch (invalid_argument &x) {
        cout << x.what() << endl << endl;
    }
    system("pause");
}

/**
 * ativa um ponto de paragem do trajeto do transporte publico
 * @param c classe usada que e para ser alterada e usada ao longo do programa
 */
void ativarPontoParagem(Gestao &g){
    cout << delim;
    cout << "\n\t\tATIVAR PONTOS DE PARAGEM";
    cout << delim << "\n\n";
    Condominio *c1;
    try {
        c1 = g.escolheCondominio(0);
        try {
            c1->recalcularTempoToCondominio();
            c1->ativarPontoDeParagem();
            c1->update = true;
            g.insereCond(c1);
        } catch (runtime_error &x) {
            g.insereCond(c1);
            cout << "\n" << x.what() << endl << endl;
        }
        catch (invalid_argument &x) {
            g.insereCond(c1);
            cout << x.what() << endl << endl;
        }
    }catch (runtime_error &x) {
        cout << "\n" << x.what() << endl << endl;
    }
    catch (invalid_argument &x) {
        cout << x.what() << endl << endl;
    }
    system("pause");
}

/**
 * desativa um ponto de paragem do trajeto do transporte publico
 * @param c classe usada que e para ser alterada e usada ao longo do programa
 */
void desativarPontoParagem(Gestao &g){
    cout << delim;
    cout << "\n\t\tDESATIVAR PONTOS DE PARAGEM";
    cout << delim << "\n\n";
    Condominio *c1;
    try {
        c1 = g.escolheCondominio(1);
        try {
            c1->recalcularTempoToCondominio();
            c1->desativarPontoDeParagem();
            c1->update = true;
            g.insereCond(c1);
        } catch (runtime_error &x) {
            g.insereCond(c1);
            cout << "\n" << x.what() << endl << endl;
        }
        catch (invalid_argument &x) {
            g.insereCond(c1);
            cout << x.what() << endl << endl;
        }
    }
    catch (runtime_error &x) {
        cout << "\n" << x.what() << endl << endl;
    }
    catch (invalid_argument &x) {
        cout << x.what() << endl << endl;
    }
    system("pause");
}

/**
 * altera o destino de um transporte publico do condominio
 * @param c classe usada que e para ser alterada e usada ao longo do programa
 */
void alterarDestinoTransporte(Gestao &g){
    cout << delim;
    cout << "\n\t\tALTERAR DESTINO DO TRANSPORTE";
    cout << delim << "\n\n";
    Condominio *c1;
    try {
        c1 = g.escolheCondominio(0);
        try {
            c1->recalcularTempoToCondominio();
            c1->alterarDestinoTransporte();
            c1->update = true;
            g.insereCond(c1);
        } catch (runtime_error &x) {
            g.insereCond(c1);
            cout << "\n" << x.what() << endl << endl;
        }
        catch (invalid_argument &x) {
            g.insereCond(c1);
            cout << x.what() << endl << endl;
        }
    }
    catch (runtime_error &x) {
        cout << "\n" << x.what() << endl << endl;
    }
    catch (invalid_argument &x) {
        cout << x.what() << endl << endl;
    }
    system("pause");
}

/**
 * ver os transportes que vao para um determinado destino definido pelo utilizador
 * @param c1 classe usada que e para ser alterada e usada ao longo do programa
 */
void verTranspToDestino(Gestao &g){
    string destino;
    cout << delim;
    cout << "\n\t\tVER TRANSPORTES COM DESTINO PRE-DEFINIDO";
    cout << delim << "\n\n";
    Condominio *c1;
    try {
        c1=g.escolheCondominio(1);
        cout<<"Destino: ";
        getline(cin,destino);
        cout<<endl;
        formataNome(destino);
        c1->verTransportesToDestino(destino);
    }catch (runtime_error &x){
        cout << "\n" << x.what() << endl << endl;
    }
    catch(invalid_argument &x){
        cout << x.what() << endl << endl;
    }
    system("pause");
}

/**
 * ver todos os transportes publicos do condominio
 * @param c1 classe usada que e para ser alterada e usada ao longo do programa
 */
void verTodosTransp(Gestao &g){
    cout << delim;
    cout << "\n\t\tVER TODOS OS TRANSPORTES";
    cout << delim << "\n\n";
    Condominio *c1;
    try{
        c1=g.escolheCondominio(1);
        c1->verTodosTransportes();
    }catch (runtime_error &x){
        cout << "\n" << x.what() << endl << endl;
    }
    catch(invalid_argument &x){
        cout << x.what() << endl << endl;
    }
    system("pause");
}

/**
 * motra a informacao dos transportes
 * @param c classe usada que e para ser alterada e usada ao longo do programa
 */
void verTransp(Gestao &c){

    int op;
    while(1){
        cout << delim;
        cout << "\n\t\tMENU VER INFO TRANSPORTES";
        cout << delim << "\n\n";
        std::cout << "1) Ver Transportes com destino pre-definido;\n2) Ver Todos os Transportes;\n3) Voltar;\n0) Sair;";
        op = Opcao(true,3);
        switch(op){
            case 1:
                verTranspToDestino(c);
                break;
            case 2:
                verTodosTransp(c);
                break;
            case 3:
                return;
            case 0:
                c.writeFile();
        }
    }
}

/**
 * mostra todos os servicos do condominio
 * @param c classe usada que e para ser alterada e usada ao longo do programa
 */
void verTodosServicos(Gestao &c){
    cout << delim;
    cout << "\n\t\tVER TODOS SERVICOS";
    cout << delim << "\n\n";
    Condominio* c1;
    try {
        c1 = c.escolheCondominio(1);
        c1->imprimeTodosServicos();
    }
    catch (runtime_error &x) {
        cout << "\n" << x.what() << endl << endl;
    }
    catch(invalid_argument &x){
        cout << x.what() << endl << endl;
    }
    system("pause");
}

/**
 * mostra todos os servicos do condominio por ordem cronologica
 * @param c classe usada que e para ser alterada e usada ao longo do programa
 */
void verServicosOrdemCrono(Gestao &c){
    cout << delim;
    cout << "\n\t\tVER TODOS SERVICOS POR ORDEM CRONOLOGICA";
    cout << delim << "\n\n";
    Condominio* c1;
    try {
        c1 = c.escolheCondominio(1);
        c1->imprimeServicosOrdemCrono();
    }
    catch (runtime_error &x) {
        cout << "\n" << x.what() << endl << endl;
    }
    catch(invalid_argument &x){
        cout << x.what() << endl << endl;
    }
    system("pause");
}

/**
 * mostra todos os servicos que estao a decorrer,cancelados ou terminados
 * @param c classe usada que e para ser alterada e usada ao longo do programa
 */
void verServicosPorEstado(Gestao &c){
    int op;
    Condominio* c1;
    cout << delim;
    cout << "\n\t\tVER TODOS SERVICOS POR ESTADO";
    cout << delim << "\n\n";
    try {
        c1 = c.escolheCondominio(1);
        cout<<"\n1) A Decorrer;\n2) Cancelados;\n3) Terminados:\n0) Voltar;";
        op=Opcao(true, 3);
        if (op==0)
            return;
        c1->imprimeServicosPorEstado(op);
        cout<<"\n";
    }
    catch (runtime_error &x) {
        cout << "\n" << x.what() << endl << endl;
    }
    catch(invalid_argument &x){
        cout << x.what() << endl << endl;
    }
    system("pause");
}

/**
 * mostrar todos os servicos prestados numa habitacao
 * @param c classe usada que e para ser alterada e usada ao longo do programa
 */
void verServicosHabitacao(Gestao &c){
    cout << delim;
    cout << "\n\t\tVER TODOS SERVICOS PRESTADOS NUMA HABITACAO";
    cout << delim << "\n\n";
    Condominio* c1;
    try {
        c1 = c.escolheCondominio(1);
        c1->imprimeServicosHabitacao();
    }catch (invalid_argument &x){
        cout<<"\n"<< x.what() << endl << endl;
    }
    catch (runtime_error &x) {
        cout << "\n" << x.what() << endl << endl;
    }
    cout<<endl;
    system("pause");
}

/**
 * mostrar todos os servicos prestados a um cliente
 * @param c classe usada que e para ser alterada e usada ao longo do programa
 */
void verServicosCliente(Gestao &c){
    cout << delim;
    cout << "\n\t\tVER TODOS SERVICOS PRESTADOS A UM CLIENTE";
    cout << delim << "\n\n";
    Condominio* c1;
    try {
        c1 = c.escolheCondominio(1);
        c1->imprimeServicosCliente();
    }catch (invalid_argument &x){
        cout<<"\n"<< x.what() << endl << endl;
    }
    catch (runtime_error &x) {
        cout << "\n" << x.what() << endl << endl;
    }
    cout<<endl;
    system("pause");
}

/**
 * cria um servico
 * @param c classe usada que e para ser alterada e usada ao long do programa
 * @param limpeza identifica se é autorizada a criacao de um servico do tipo limpeza
 * @param indice indice do servico limpeza que pretende remover logo apos a criacao de um, permanece -1 caso nao se trate da remocao de um servico limpeza
 */
void criarServico(Gestao &c,bool limpeza,int indice=-1){
    string tipo_servico,prestador;
    float preco_mensal;
    cout << delim;
    cout << "\n\t\tCRIAR SERVICO";
    cout << delim << "\n\n";
    Condominio* c1;
    try {
        c1 = c.escolheCondominio(0);
        try {
            cout << "Tipo de Servico:";
            getline(cin, tipo_servico);
            formataNome(tipo_servico);
            cout << "Prestador:";
            getline(cin, prestador);
            formataNome(prestador);
            cout << "Preco Mensal:";
            c1->verifyServico(tipo_servico, preco_mensal, prestador, limpeza);
            Servicos c2(tipo_servico, prestador, preco_mensal);
            cout << endl << endl;
            c1->update = true;
            c1->addServico(c2, indice);
            c.insereCond(c1);
        }
        catch (runtime_error &x) {
            c.insereCond(c1);
            cout << "\n" << x.what() << endl << endl;
        }
        catch (invalid_argument &x) {
            c.insereCond(c1);
            cout << "\n" << x.what() << endl << endl;
        }
    }
    catch (runtime_error &x) {
        cout << "\n" << x.what() << endl << endl;
    }
    catch(invalid_argument &x){
        cout << x.what() << endl << endl;
    }
    system("pause");
}

/**
 * altera um servico
 * @param c classe usada que e para ser alterada e usada ao longo do programa
 */
void alterarServico(Gestao &c){
    cout << delim;
    cout << "\n\t\tALTERAR SERVICO";
    cout << delim << "\n\n";
    Condominio* c1;
    try {
        c1 = c.escolheCondominio(0);
        try {
            c1->alterarServico();
            c1->update = true;
            c.insereCond(c1);
            cout << endl << endl;
        }
        catch (runtime_error &l1) {
            c.insereCond(c1);
            cout << "\n" << l1.what() << endl << endl;
            system("pause");
        }
    }
    catch(runtime_error &l1){
        cout << "\n" << l1.what() << endl << endl;
        system("pause");
    }
    catch(invalid_argument &x){
        cout << x.what() << endl << endl;
    }
}

/**
 * remove um servico
 * @param c classe usada que e para ser alterada e usada ao longo do programa
 */
void removerServico(Gestao &c){
    int indice=-1;
    Condominio* c1;
    cout << delim;
    cout << "\n\t\tREMOVER SERVICO";
    cout << delim << "\n\n";
    try {
        c1 = c.escolheCondominio(0);
        try {
            c1->removerServico(indice);
            c1->update = true;
            c.insereCond(c1);
            cout << endl << endl;
        }
        catch (runtime_error &l1) {
            c.insereCond(c1);
            char aux;
            cout << "\n" << l1.what() << endl << endl;
            cout << "Deseja criar um servico Limpeza para assim remover este servico? (s/n)";
            cin >> aux;
            if (toupper(aux) == 'S')
                criarServico(c, true, indice);
        }
    }
    catch(runtime_error &l1){
        char aux;
        cout << "\n" << l1.what() << endl << endl;
        system("pause");
    }
    catch(invalid_argument &x){
        cout << x.what() << endl << endl;
    }
}

/**
 * inicia, cancela ou termina um servico
 * @param c classe usada que e para ser alterada e usada ao longo do programa
 */
void inic_cancel_termiServico(Gestao &c){
    int op;
    Condominio* c1;
    cout << delim;
    cout << "\n\t\tINICIAR/CANCELAR/TERMINAR SERVICO";
    cout << delim << "\n\n";
    try {
        c1 = c.escolheCondominio(0);
        while (1) {
            cout << "1) Iniciar Servico; \n2) Cancelar Servico; \n3) Terminar Servico; \n0) Voltar;" << endl;
            op = Opcao(true, 3);
            switch (op) {
                case 1: {
                    try {
                        c1->iniciarServico();
                        c1->update = true;
                        c.insereCond(c1);
                    }
                    catch (invalid_argument &x) {
                        c.insereCond(c1);
                        cout << "\n" << x.what() << endl << endl;
                        system("pause");
                    }
                    catch (runtime_error &x) {
                        c.insereCond(c1);
                        cout << "\n" << x.what() << endl << endl;
                        system("pause");
                    }
                    break;
                }
                case 2:
                    c1->cancelServico();
                    c1->update = true;
                    c.insereCond(c1);
                    break;
                case 3:
                    c1->terminarServico();
                    c1->update = true;
                    c.insereCond(c1);
                    break;
                case 0:
                    c.insereCond(c1);
                    return;
            }
        }
    }
    catch(runtime_error &x){
        cout << x.what()<< endl << endl;
    }
    catch(invalid_argument &x){
        cout << x.what() << endl << endl;
    }
}

/**
 * cria um cliente
 * @param c classe usada que e para ser alterada e usada ao longo do programa
 */
void criarCliente(Gestao &c){
    std::string aux;
    Cliente *cl = new Cliente();
    Condominio* c1;
    cout << delim;
    cout << "\n\t\tCRIAR CLIENTE";
    cout << delim << "\n\n";
    try {
        c1 = c.escolheCondominio(0);
        try {
            cout << "Introduza o nome:", getline(cin, aux), cl->setNome(aux);
            std::cout << "Introduza o NIF: ", getline(std::cin, aux);
            c1->verifyNif(aux);
            cl->setNif(aux);
            time_t t;
            struct tm * infoTempo;
            time(&t);
            infoTempo = localtime(&t);
            cl->setDia(infoTempo->tm_mday);
            cl->setSegundo(infoTempo->tm_sec);
            cl->setHora(infoTempo->tm_hour);
            cl->setMinuto(infoTempo->tm_min);
            cl->setMes(infoTempo->tm_mon + 1);
            cl->setAno(infoTempo->tm_year + 1900);
            c1->addCliente(*cl);
            c1->update = true;
            c.insereCond(c1);
        }
        catch (invalid_argument &i) {
            c.insereCond(c1);
            std::cout << i.what() << std::endl << std::endl;
            delete cl;
        }
        catch (runtime_error &l) {
            c.insereCond(c1);
            std::cout << l.what() << std::endl << std::endl;
            delete cl;
        }
    }
    catch(runtime_error &l){
        std::cout << l.what() << std::endl << std::endl;
    }
    catch(invalid_argument &x){
        cout << x.what() << endl << endl;
    }
    system("pause");
}

/**
 * altera um cliente
 * @param c classe usada que e para ser alterada e usada ao longo do programa
 */
void alterarCliente(Gestao &c){
    cout << delim;
    cout << "\n\t\tALTERAR CLIENTE";
    cout << delim << "\n\n";
    Condominio* c1;
    try {
        c1 = c.escolheCondominio(0);
        try {
            c1->alterarCliente();
            c1->update = true;
            c.insereCond(c1);
            cout << endl << endl;
        }
        catch (invalid_argument &i) {
            c.insereCond(c1);
            cout << i.what() << endl << endl;
        }
        catch (runtime_error &e) {
            c.insereCond(c1);
            cout << e.what() << endl << endl;
        }
    }
    catch(runtime_error &e){
        cout << e.what() << endl << endl;
    }
    catch(invalid_argument &x){
        cout << x.what() << endl << endl;
    }
    system("pause");
}

/**
 * remove um cliente
 * @param c classe usada que e para ser alterada e usada ao longo do programa
 */
void removerCliente(Gestao &c){
    cout << delim;
    cout << "\n\t\tREMOVER CLIENTE";
    cout << delim << "\n\n";
    Condominio* c1;
    try {
        c1 = c.escolheCondominio(0);
        try {
            c1->removerCliente();
            c1->update = true;
            c.insereCond(c1);
            cout << endl << endl;
        }
        catch (runtime_error &e) {
            c.insereCond(c1);
            cout << e.what() << endl << endl;
        }
        catch (invalid_argument &i) {
            c.insereCond(c1);
            cout << i.what() << endl << endl;
        }
    }
    catch(runtime_error &i){
        cout << i.what() << endl << endl;
    }
    catch(invalid_argument &x){
        cout << x.what() << endl << endl;
    }
    system("pause");
}

/**
 * associa uma habitacao a um cliente
 * @param c classe usada que e para ser alterada e usada ao longo do programa
 */
void associarHabit(Gestao &c){
    cout << delim;
    cout << "\n\t\tADQUIRIR HABITACAO";
    cout << delim << "\n\n";
    Condominio* c1;
    try {
        c1 = c.escolheCondominio(0);
        try {
            c1->associarHabit();
            c1->update = true;
            c.insereCond(c1);
        }
        catch (runtime_error &e) {
            c.insereCond(c1);
            cout << e.what() << endl << endl;
        }
        catch (invalid_argument &i) {
            c.insereCond(c1);
            cout << i.what() << endl << endl;
        }
    }
    catch(runtime_error &i) {
        cout << i.what() << endl << endl;
    }
    catch(invalid_argument &x){
        cout << x.what() << endl << endl;
    }
    system("pause");
}

/**
 * desassocia uma habitacao
 * @param c classe usada que e para ser alterada e usada ao longo do programa
 */
void desassociarHabit(Gestao &c){
    cout << delim;
    cout << "\n\t\tDESASSOCIAR HABITACAO";
    cout << delim << "\n\n";
    Condominio* c1;
    try {
        c1 = c.escolheCondominio(0);
        try {
            c1->desassociarHabit();
            c1->update = true;
            c.insereCond(c1);
            cout << endl << endl;
        }
        catch (runtime_error &e) {
            c.insereCond(c1);
            cout << e.what() << endl << endl;
        }
        catch (invalid_argument &i) {
            c.insereCond(c1);
            cout << i.what() << endl << endl;
        }
    }
    catch (runtime_error &e) {
        cout << e.what() << endl << endl;
    }
    catch(invalid_argument &x){
        cout << x.what() << endl << endl;
    }
    system("pause");
}

/**
 * cria uma vivenda e adiciona a classe Condominio
 * @param c classe usada que e para ser alterada e usada ao longo do programa
 */
void criarVivenda(Gestao &c){
    std::string aux;
    Vivenda *v = new Vivenda();
    cout << delim;
    cout << "\n\t\tCRIAR VIVENDA";
    cout << delim << "\n\n";
    Condominio* c1;
    try {
        c1 = c.escolheCondominio(0);
        try {
            v->setTipo("Vivenda");
            cout << "Introduza o ID:";
            getline(cin, aux);
            v->setId(aux);
            c1->verifyId(stoi(aux));
            std::cout << "Introduza a morada:";
            getline(std::cin, aux);
            v->setMorada(aux);
            std::cout << "Introduza o Valor Base:";
            getline(std::cin, aux);
            v->setValorBase(aux);
            std::cout << "Introduza a Area de Habitacao:";
            getline(std::cin, aux);
            v->setAreaHabitacional(aux);
            std::cout << "Introduza a Area Exterior:";
            getline(std::cin, aux);
            v->setAreaExterior(aux);
            std::cout << "Introduza se tem Piscina('sim'/'nao'):";
            getline(std::cin, aux);
            v->setPiscina(aux);
            v->setPago("nao");
            v->calcImposto();
            v->setDisponibilidade("sim");
            v->setProprietario("-");
            c1->addHabitacao(v);   //adiciona a vivenda ao cliente
            c1->update = true;
            c.insereCond(c1);
        }
        catch (invalid_argument &l) {
            c.insereCond(c1);
            std::cout << l.what() << std::endl << std::endl;
            delete v;
        }
        catch (runtime_error &r) {
            c.insereCond(c1);
            std::cout << r.what() << endl << endl;
            delete v;
        }
    }
    catch (runtime_error &r) {
        std::cout << r.what() << endl << endl;
        delete v;
    }
    catch(invalid_argument &x){
        cout << x.what() << endl << endl;
    }
    system("pause");
}

/**
 * cria um apartamento e adicionao a classe Condominio
 * @param c classe usada que e para ser alterada e usada ao longo do programa
 */
void criarApartamento(Gestao &c) {
    std::string aux;
    Apartamento *a = new Apartamento();
    cout << delim;
    cout << "\n\t\tCRIAR APARTAMENTO";
    cout << delim << "\n\n";
    Condominio* c1;
    try {
        c1 = c.escolheCondominio(0);
        try {
            a->setTipo("Apartamento");
            cout << "Introduza o ID:", getline(cin, aux), a->setId(aux);
            c1->verifyId(stoi(aux));
            std::cout << "Introduza a morada:";
            getline(std::cin, aux);
            a->setMorada(aux);
            std::cout << "Introduza o Valor Base:";
            getline(std::cin, aux);
            a->setValorBase(aux);
            std::cout << "Introduza a Area de Habitacao:";
            getline(std::cin, aux);
            a->setAreaHabitacional(aux);
            std::cout << "Introduza o Piso:";
            getline(std::cin, aux);
            a->setPiso(aux);
            std::cout << "Introduza a Tipologia:";
            getline(std::cin, aux);
            a->setTipologia(aux);
            a->setPago("nao");
            a->calcImposto();
            a->setDisponibilidade("sim");
            a->setProprietario("-");
            c1->addHabitacao(a);    //adiciona apartamento ao cliente
            c1->update = true;
            c.insereCond(c1);
        }
        catch (invalid_argument &l) {
            c.insereCond(c1);
            std::cout << l.what() << std::endl << std::endl;
            delete a;
        }
        catch (runtime_error &r) {
            c.insereCond(c1);
            std::cout << r.what() << endl << endl;
            delete a;
        }
    }
    catch (runtime_error &r) {
        std::cout << r.what() << endl << endl;
        delete a;
    }
    catch(invalid_argument &x){
        cout << x.what() << endl << endl;
    }
    system("pause");
}

/**
 * altera a Habitacao escolhida pelo utilizador atraves das moradas
 * @param c classe usada que e para ser alterada e usada ao longo do programa
 */
void alterarHabitacao(Gestao &c){
    cout << delim;
    cout << "\n\t\tALTERAR HABITACAO";
    cout << delim << "\n\n";
    Condominio* c1;
    try {
        c1 = c.escolheCondominio(0);
        try {
            c1->alterarHabitacao();
            c1->update = true;
            c.insereCond(c1);
            cout << endl << endl;
        }
        catch (invalid_argument &i) {
            c.insereCond(c1);
            cout << i.what() << endl << endl;
        }
        catch (runtime_error &e) {
            c.insereCond(c1);
            cout << e.what() << endl << endl;
        }
    }
    catch (runtime_error &e) {
        cout << e.what() << endl << endl;
    }
    catch(invalid_argument &x){
        cout << x.what() << endl << endl;
    }
    system("pause");
}

/**
 * remove uma habitacao do condominio
 * @param c classe usada que e para ser alterada e usada ao longo do programa
 */
void removerHabitacao(Gestao &c){
    cout << delim;
    cout << "\n\t\tREMOVER HABITACAO";
    cout << delim << "\n\n";
    Condominio* c1;
    try {
        c1 = c.escolheCondominio(0);
        try {
            c1->removerHabitacao();
            c1->update = true;
            c.insereCond(c1);
            cout << endl << endl;
        }
        catch (invalid_argument &i) {
            c.insereCond(c1);
            cout << i.what() << endl << endl;
        }
        catch (runtime_error &e) {
            c.insereCond(c1);
            cout << e.what() << endl << endl;
        }
    }
    catch (runtime_error &e) {
        cout << e.what() << endl << endl;
    }
    catch(invalid_argument &x){
        cout << x.what() << endl << endl;
    }
    system("pause");
}

/**
 * funcao que serve para pagar a mensalidade de uma casa que pertence a um determinado cliente
 * @param c classe usada que e para ser alterada e usada ao longo do programa
 */
void pagMen(Gestao &c){
    cout << delim;
    cout << "\n\t\tPAGAR MENSALIDADE";
    cout << delim << "\n\n";
    Condominio* c1;
    try {
        c1 = c.escolheCondominio(0);
        try {
            c1->pagar();
            c1->update = true;
            c.insereCond(c1);
            cout << endl << endl;
        }
        catch (runtime_error &e) {
            c.insereCond(c1);
            cout << e.what() << endl << endl;
        }
        catch (invalid_argument &i) {
            c.insereCond(c1);
            cout << i.what() << endl << endl;
        }
    }
    catch (runtime_error &e) {
        cout << e.what() << endl << endl;
    }
    catch(invalid_argument &x){
        cout << x.what() << endl << endl;
    }
    system("pause");
}

/**
 * mostra todos os clientes do condominio
 * @param c classe usada que e para ser alterada e usada ao longo do programa
 */
void verTodosClientes(Gestao &c){
    cout << delim;
    cout << "\n\t\tVER TODOS CLIENTES";
    cout << delim << "\n\n";
    Condominio* c1;
    try{
        c1 = c.escolheCondominio(1);
        c1->imprimeTodosClientes(0);
    }
    catch(runtime_error &x){
        cout << x.what() << endl << endl;
    }
    catch(invalid_argument &x){
        cout << x.what() << endl << endl;
    }
    system("pause");
}

/**
 * mostra todas as habitacoes do condominio
 * @param c classe usada que e para ser alterada e usada ao longo do programa
 */
void verTodasHabitacoes(Gestao &c){
    cout << delim;
    cout << "\n\t\tVER TODAS HABITACOES";
    cout << delim << "\n\n";
    Condominio* c1;
    try{
        c1 = c.escolheCondominio(1);
        c1->verTodosHabitacoes(0);
    }
    catch(runtime_error &x){
        cout << x.what() << endl << endl;
    }
    catch(invalid_argument &x){
        cout << x.what() << endl << endl;
    }
    system("pause");
}

/**
 * mostra um cliente especifico
 * @param c classe usada que e para ser alterada e usada ao longo do programa
 */
void verClienteEsp(Gestao &c){
    cout << delim;
    cout << "\n\t\tVER CLIENTE ESPECIFICO";
    cout << delim << "\n\n";
    Condominio* c1;
    try {
        c1 = c.escolheCondominio(1);
        c1->imprimeCliente();
    }
    catch(runtime_error &i){
        cout <<  i.what() << endl << endl;
    }
    catch(invalid_argument &i){
        cout << i.what() << endl << endl;
    }
    system("pause");
}

/**
 * mostra habitacao especifica
 * @param c classe usada que e para ser alterada e usada ao longo do programa
 */
void verHabitacaoEsp(Gestao &c){
    cout << delim;
    cout << "\n\t\tVER HABITACAO ESPECIFICA";
    cout << delim << "\n\n";
    Condominio* c1;
    try {
        c1 = c.escolheCondominio(1);
        c1->verHabitacaoEsp();
    }
    catch(invalid_argument &i){
        cout << i.what() << endl << endl;
    }
    catch(runtime_error &i){
        cout << i.what() << endl << endl;
    }
    system("pause");
}

/**
 *mostra todas as habitacoes do condominio ordenadas por Id
 * @param c classe usada que e para ser alterada e usada ao longo do programa
 */
void verOrdId(Gestao &c){
    cout << delim;
    cout << "\n\t\tVER TODAS HABITACOES ORDENADAS POR ID";
    cout << delim << "\n\n";
    Condominio* c1;
    try{
        c1 = c.escolheCondominio(1);
        c1->verTodosHabitacoes(1);
    }
    catch(runtime_error &x){
        cout << x.what() << endl << endl;
    }
    catch(invalid_argument &x){
        cout << x.what() << endl << endl;
    }
    system("pause");
}

/**
 *mostra todas as habitacoes do condominio ordenadas por Area Habitacional
 * @param c classe usada que e para ser alterada e usada ao longo do programa
 */
void verOrdAreHab(Gestao &c){
    cout << delim;
    cout << "\n\t\tVER TODAS HABITACOES ORDENADAS POR AREA HABITACIONAL";
    cout << delim << "\n\n";
    Condominio* c1;
    try{
        c1 = c.escolheCondominio(1);
        c1->verTodosHabitacoes(2);
    }
    catch(runtime_error &x){
        cout << x.what() << endl << endl;
    }
    catch(invalid_argument &x){
        cout << x.what() << endl << endl;
    }
    system("pause");
}

/**
 * mostra os clientes ordenados por nome
 * @param c classe usada que e para ser alterada e usada ao longo do programa
 */
void verClienteOrd(Gestao &c){
    cout << delim;
    cout << "\n\t\tVER TODOS CLIENTES ORDENADOS POR NOME";
    cout << delim << "\n\n";
    Condominio* c1;
    try{
        c1 = c.escolheCondominio(1);
        c1->imprimeTodosClientes(1);
    }
    catch(runtime_error &x){
        cout << x.what() << endl << endl;
    }
    catch(invalid_argument &x){
        cout << x.what() << endl << endl;
    }
    system("pause");
}

/**
 * mostra todos os apartamentos
 * @param c classe usada que e para ser alterada e usada ao longo do programa
 */
void verAp(Gestao &c){
    cout << delim;
    cout << "\n\t\tVER TODOS OS APARTAMENTOS";
    cout << delim << "\n\n";
    Condominio* c1;
    try{
        c1 = c.escolheCondominio(1);
        c1->imprimeApartamentos();
    }
    catch(runtime_error &x){
        cout << x.what() << endl << endl;
    }
    catch(invalid_argument &x){
        cout << x.what() << endl << endl;
    }
    system("pause");
}

/**
 * mostra todas as vivendas
 * @param c classe usada que e para ser alterada e usada ao longo do programa
 */
void verViv(Gestao &c){
    cout << delim;
    cout << "\n\t\tVER TODAS AS VIVENDAS";
    cout << delim << "\n\n";
    Condominio* c1;
    try{
        c1 = c.escolheCondominio(1);
        c1->imprimeVivendas();
    }
    catch(runtime_error &x){
        cout << x.what() << endl << endl;
    }
    catch(invalid_argument &x){
        cout << x.what() << endl << endl;
    }
    system("pause");
}

/**
 * mostra o lucro do condominio com base nas mensalidades
 * @param c classe usada que e para ser alterada e usada ao longo do programa
 */
void verLucMen(Gestao &c){
    cout << delim;
    cout << "\n\t\tVER LUCRO DO CONDOMINIO COM BASE NAS MENSALIDADES";
    cout << delim << "\n\n";
    Condominio* c1;
    try{
        c1 = c.escolheCondominio(1);
        c1->verLucMen();
    }
    catch(runtime_error &x){
        cout << x.what() << endl << endl;
    }
    catch(invalid_argument &x){
        cout << x.what() << endl << endl;
    }
    system("pause");

}

/**
 * mostra as despesas do condominio
 * @param c classe usada que e para ser alterada e usada ao longo do programa
 */
void verDesp(Gestao &c){
    Condominio* c1;
    cout << delim;
    cout << "\n\t\tVER DESPESAS DO CONDOMINIO COM BASE NOS SERVICOS";
    cout << delim << "\n\n";
    try{
        c1 = c.escolheCondominio(1);
        c1->verDesp();
    }
    catch(runtime_error &x){
        cout << x.what() << endl << endl;
    }
    catch(invalid_argument &x){
        cout << x.what() << endl << endl;
    }
    system("pause");
}

/**
 * cria um novo condominio
 * @param g classe usada que e para ser alterada e usada ao longo do programa
 */
void criarCond(Gestao &g){
    cout << delim;
    cout << "\n\t\tCRIAR CONDOMINIO";
    cout << delim << "\n\n";
    try{
        g.criaCond();
    }
    catch(runtime_error &x){
        cout << x.what() << endl << endl;
    }
    catch(invalid_argument &x){
        cout << x.what() << endl << endl;
    }
    system("pause");
}

/**
 * altera um condominio
 * @param g classe usada que e para ser alterada e usada ao longo do programa
 */
void altCond(Gestao &g){
    cout << delim;
    cout << "\n\t\tALTERAR CONDOMINIO";
    cout << delim << "\n\n";
    Condominio *c;
    try{
        c = g.escolheCondominio(0);
        try{
            g.altCond(c);
        }
        catch(runtime_error &x){
            cout << x.what() << endl << endl;
        }
        catch(invalid_argument &x){
            cout << x.what() << endl << endl;
        }
    }
    catch(runtime_error &x){
        cout << x.what() << endl << endl;
    }
    catch(invalid_argument &x){
        cout << x.what() << endl << endl;
    }
    system("pause");
}

/**
 * remove um condominio
 * @param g classe usada que e para ser alterada e usada ao longo do programa
 */
void remCond(Gestao &g){
    cout << delim;
    cout << "\n\t\tREMOVER CONDOMINIO";
    cout << delim << "\n\n";
    Condominio *c;
    try{
        g.remCond();
    }
    catch(runtime_error &x){
        cout << x.what() << endl << endl;
    }
    catch(invalid_argument &x){
        cout << x.what() << endl << endl;
    }
    system("pause");
}

/**
 * mostra um condominio especifico
 * @param g classe usada que e para ser alterada e usada ao longo do programa
 */
void verCondEsp(Gestao &g){
    cout << delim;
    cout << "\n\t\tVER CONDOMINIO ESPECIFICO";
    cout << delim << "\n\n";
    Condominio *c;
    try{
        c = g.escolheCondominio(1);
        g.verCondEsp(c->getNome());
    }
    catch(runtime_error &x){
        cout << x.what() << endl << endl;
    }
    catch(invalid_argument &x){
        cout << x.what() << endl << endl;
    }
    system("pause");
}

/**
 * mostra todos os condominios por ordem crescente
 * @param g classe usada que e para ser alterada e usada ao longo do programa
 */
void verTodosCondOrdCres(Gestao &g){
    cout << delim;
    cout << "\n\t\tVER TODOS OS CONDOMINIOS POR ORDEM CRESCENTE";
    cout << delim << "\n\n";
    g.verTodosCond(0);
}

/**
 * mostra todos os condominios por ordem decrescente
 * @param g classe usada que e para ser alterada e usada ao longo do programa
 */
void verTodosCondOrdDecres(Gestao &g){
    cout << delim;
    cout << "\n\t\tVER TODOS OS CONDOMINIOS POR ORDEM DECRESCENTE";
    cout << delim << "\n\n";
    g.verTodosCond(1);
};

/**
 * mostra todos os antigos clientes
 * @param c classe usada que e para ser alterada e usada ao longo do programa
 */
void verTodAntCli(Gestao &c){
    cout << delim;
    cout << "\n\t\tVER TODOS OS ANTIGOS CLIENTES";
    cout << delim << "\n\n";
    Condominio* c1;
    try{
        c1 = c.escolheCondominio(1);
        c1->imprimeTodosAntigosClientes();
    }
    catch(runtime_error &x){
        cout << x.what() << endl << endl;
    }
    catch(invalid_argument &x){
        cout << x.what() << endl << endl;
    }
    system("pause");
}

/**
 * mostra um antigo cliente especifico
 * @param g classe usada que e para ser alterada e usada ao longo do programa
 */
void verAntCliEsp(Gestao &c){
    cout << delim;
    cout << "\n\t\tVER ANTIGO CLIENTE ESPECIFICO";
    cout << delim << "\n\n";
    Condominio* c1;
    try{
        c1 = c.escolheCondominio(1);
        c1->imprimeAntigoClienteEspecifico();
    }
    catch(runtime_error &x){
        cout << x.what() << endl << endl;
    }
    catch(invalid_argument &x){
        cout << x.what() << endl << endl;
    }
    system("pause");
}
//---------------------------------------------------------
//                  MENUS
//---------------------------------------------------------

void verAntCli(Gestao &c){
    bool ON = true;
    int op;
    while(ON){
        cout << delim;
        cout << "\n\t\tMENU VER ANTIGOS CLIENTES";
        cout << delim << "\n\n";
        std::cout << "1) Ver Todos os Antigos Clientes;\n2) Ver Antigo Cliente Especifico;\n3) Voltar;\n0) Sair;";
        op = Opcao(true,3);
        switch(op){
            case 1:
                verTodAntCli(c);
                break;
            case 2:
                verAntCliEsp(c);
                break;
            case 3:
                return;
            case 0:
                c.writeFile();
        }
    }
}

/**
 * mostra o menu ver Servico
 * @param c classe usada que e para ser alterada e usada ao longo do programa
 */
void verServicos(Gestao &c){
    int op;
    while(1){
        cout << delim;
        cout << "\n\t\tMENU VER SERVICOS";
        cout << delim << "\n\n";
        std::cout << "1) Ver Todos os Servicos;\n2) Ver Todos os Servicos Prestados por Ordem Cronologica;\n3) Ver Todos os Servicos a Decorrer,Cancelados ou Terminados;\n4) Ver Todos os Servicos Prestados Numa Habitacao;\n5) Ver Todos os Servicos Prestados a um Cliente;\n6) Voltar;\n0) Sair;";
        op = Opcao(true,6);
        switch(op){
            case 1:
                verTodosServicos(c);
                break;
            case 2:
                verServicosOrdemCrono(c);
                break;
            case 3:
                verServicosPorEstado(c);
                break;
            case 4:
                verServicosHabitacao(c);
                break;
            case 5:
                verServicosCliente(c);
                break;
            case 6:
                return;
            case 0:
                c.writeFile();
        }
    }
}

/**
 * menu que permite escolher entre criar habitacao e vivenda
 * @param c classe usada que e para ser alterada e usada ao longo do programa
 */
void criarHabitacao(Gestao &c){
    bool ON = true;
    int op;
    while(ON){
        cout << delim;
        cout << "\n\t\tCRIAR HABITACAO";
        cout << delim << "\n\n";
        std::cout << "1) Criar Vivenda;\n2) Criar Apartamento;\n3) Voltar;\n0) Sair;";
        op = Opcao(true,3);
        switch(op){
            case 1:
                criarVivenda(c);
                break;
            case 2:
                criarApartamento(c);
                break;
            case 3:
                return;
            case 0:
                c.writeFile();
        }
    }
}

/**
 * mostra o menu ver Clientes
 * @param c classe usada que e para ser alterada e usada ao longo do programa
 */
 void verClientes(Gestao &c){
    bool ON = true;
    int op;
    while(ON){
        cout << delim;
        cout << "\n\t\tMENU VER CLIENTES";
        cout << delim << "\n\n";
        std::cout << "1) Ver Todos os Clientes;\n2) Ver Cliente Especifico;\n3) Ver Clienes ordenados por Nome;\n4) Voltar;\n0) Sair;";
        op = Opcao(true,4);
        switch(op){
            case 1:
                verTodosClientes(c);
                break;
            case 2:
                verClienteEsp(c);
                break;
            case 3:
                verClienteOrd(c);
                break;
            case 4:
                return;
            case 0:
                c.writeFile();
        }
    }
 }

 /**
  * mostra o menu ver pacotes
  * @param c classe usada que e para ser alterada e usada ao longo do programa
  */
 void verHabitacoes(Gestao &c){
     bool ON = true;
     int op;
     while(ON){
         cout << delim;
         cout << "\n\t\tMENU VER HABITACOES";
         cout << delim << "\n\n";
         std::cout << "1) Ver Todas as Habitacoes;\n2) Ver Habitacao Especifica;\n3) Ver Habitacoes Ordenadas por Id;\n4) Ver Habitacoes Ordenadas por Area Habitacional;\n5) Ver Vivendas;\n6) Ver Apartamentos;\n7) Voltar;\n0) Sair;";
         op = Opcao(true,7);
         switch(op){
             case 1:
                 verTodasHabitacoes(c);
                 break;
             case 2:
                 verHabitacaoEsp(c);
                 break;
             case 3:
                 verOrdId(c);
                 break;
             case 4:
                 verOrdAreHab(c);
                 break;
             case 5:
                 verViv(c);
                 break;
             case 6:
                 verAp(c);
                 break;
             case 7:
                 return;
             case 0:
                 c.writeFile();
         }
     }
 }

 /**
  * mostra o menu ver condominios
  * @param g classe usada que e para ser alterada e usada ao longo do programa
  */
 void verCond(Gestao &c){
     bool ON = true;
     int op;
     while(ON){
         cout << delim;
         cout << "\n\t\tMENU VER CONDOMINIOS";
         cout << delim << "\n\n";
         std::cout << "1) Ver Todos os Condominios por Ordem Crescente;\n2) Ver Todos os Condominios por Ordem Descrescente\n3) Ver Condominio Especifico;\n4) Voltar;\n0) Sair;";
         op = Opcao(true,4);
         switch(op){
             case 1:
                 verTodosCondOrdCres(c);
                 break;
             case 2:
                 verTodosCondOrdDecres(c);
                 break;
             case 3:
                 verCondEsp(c);
                 break;
             case 4:
                 return;
             case 0:
                 c.writeFile();
         }
     }
 }

/**
 * mostra o menu ver info
 * @param c classe usada que e para ser alterada e usada ao longo do programa
 */
void verInfo(Gestao &c){
    bool ON = true;
    int op;
    while(ON){
        cout << delim;
        cout << "\n\t\tMENU VER INFO";
        cout << delim << "\n\n";
        std::cout << "1) Ver Clientes;\n2) Ver Habitacoes;\n3) Ver Servicos;\n4) Ver Lucro com base nas Mensalidades;\n5) Ver Despesas com base nos Servicos;\n6) Ver Condominios;\n7) Ver Antigos Clientes;\n8) Ver Transportes;\n9) Voltar;\n0) Sair;";
        op = Opcao(true,9);
        switch(op){
            case 1:
                verClientes(c);
                break;
            case 2:
                verHabitacoes(c);
                break;
            case 3:
                verServicos(c);
                break;
            case 4:
                verLucMen(c);
                break;
            case 5:
                verDesp(c);
                break;
            case 6:
                verCond(c);
                break;
            case 7:
                verAntCli(c);
                break;
            case 8:
                verTransp(c);
                break;
            case 9:
                return;
            case 0:
                c.writeFile();
        }
    }
}

/**
 * mostra o menu gerir servicos
 * @param c classe usada que e para ser alterada e usada ao longo do programa
 */
void gerServ(Gestao &c){
    bool ON=true;
    int op;
    while(ON){
        cout << delim;
        cout << "\n\t\tMENU GERIR SERVICOS";
        cout << delim << "\n\n";
        cout<< "1) Criar Servico;\n2) Alterar Servico;\n3) Remover Servico;\n4) Inicar/Cancelar/Terminar Servico;\n5) Voltar;\n0) Sair;";
        op= Opcao(true,5);
        switch (op){
            case 1:
                criarServico(c, false);
                break;
            case 2:
                alterarServico(c);
                break;
            case 3:
                removerServico(c);
                break;
            case 4:
                inic_cancel_termiServico(c);
                break;
            case 5:
                return;
            case 0:
                c.writeFile();
        }
    }
}

/**
 * mostra o menu geir habitacoes
 * @param c classe usada que e para ser alterada e usada ao longo do programa
 */
void gerHabit(Gestao &c){
    bool ON = true;
    int op;
    while(ON){
        cout << delim;
        cout << "\n\t\tMENU GERIR HABITACOES";
        cout << delim << "\n\n";
        std::cout << "1) Criar Habitacao;\n2) Alterar Habitacao;\n3) Remover Habitacao;\n4) Voltar;\n0) Sair;";
        op = Opcao(true, 4);
        switch(op){
            case 1:
                criarHabitacao(c);
                break;
            case 2:
                alterarHabitacao(c);
                break;
            case 3:
                removerHabitacao(c);
                break;
            case 4:
                return;
            case 0:
                c.writeFile();
        }
    }
}

/**
  * mostra o menu gerir clientes
  * @param c classe usada que e para ser alterada e usada ao longo do programa
  */
void gerCli(Gestao &c){
    bool ON = true;
    int op;
    while(ON){
        cout << delim;
        cout << "\n\t\tMENU GERIR CLIENTES";
        cout << delim << "\n\n";
        std::cout << "1) Criar Cliente;\n2) Alterar Cliente;\n3) Remover Cliente;\n4) Pagar Mensalidade;\n5) Comprar Habitacao; \n6) Desassociar Habitacao;\n7) Voltar;\n0) Sair;";
        op = Opcao(true, 7);
        switch(op){
            case 1:
                criarCliente(c);
                break;
            case 2:
                alterarCliente(c);
                break;
            case 3:
                removerCliente(c);
                break;
            case 4:
                pagMen(c);
                break;
            case 5:
                associarHabit(c);
                break;
            case 6:
                desassociarHabit(c);
                break;
            case 7:
                return;
            case 0:
                c.writeFile();
        }
    }
}

/**
 * mostra o menu gerir condominio
 * @param g classe usada que e para ser alterada e usada ao longo do programa
 */
void gerCond(Gestao &g){
    bool ON = true;
    int op;
    while(ON){
        cout << delim;
        cout << "\n\t\tMENU GERIR CONDOMINIO";
        cout << delim << "\n\n";
        std::cout << "1) Criar Condominio;\n2) Alterar Condominio;\n3) Remover Condominio;\n4) Voltar;\n0) Sair;";
        op = Opcao(true, 4);
        switch(op){
            case 1:
                criarCond(g);
                break;
            case 2:
                altCond(g);
                break;
            case 3:
                remCond(g);
                break;
            case 4:
                return;
            case 0:
                g.writeFile();
        }
    }
}

/**
 * mostra o menu gerir transportes
 * @param g classe usada que e para ser alterada e usada ao longo do programa
 */
void gerTransp(Gestao &g){
    bool ON = true;
    int op;
    while(ON){
        cout << delim;
        cout << "\n\t\tMENU GERIR TRANSPORTES";
        cout << delim << "\n\n";
        std::cout << "1) Criar Novos Pontos de Paragem;\n2) Desativar Pontos de Paragem;\n3) Ativar Pontos de Paragem;\n4) Alterar Destino do Tranporte;\n5) Voltar;\n0) Sair;";
        op = Opcao(true, 5);
        switch(op){
            case 1:
                criarPontosParagem(g);
                break;
            case 2:
                desativarPontoParagem(g);
                break;
            case 3:
                ativarPontoParagem(g);
                break;
            case 4:
                alterarDestinoTransporte(g);
                break;
            case 5:
                return;
            case 0:
                g.writeFile();
        }
    }
}

/**
 * mostra o menu Principal
 * @param c classe usada que e para ser alterada e usada ao longo do programa
 */
void mainMenu(Gestao &g){
    bool ON = true;
    int op;
    while(ON){
        cout << delim;
        cout << "\n\t\tMENU PRINCIPAL";
        cout << delim << "\n\n";
        std::cout << "1) Gerir Habitacoes;\n2) Gerir Clientes;\n3) Gerir Servicos;\n4) Gerir Condominio;\n5) Gerir Transportes;\n6) Ver Info;\n0) Sair;";
        op = Opcao(true,6);
        switch(op){
            case 1:
                gerHabit(g);
                break;
            case 2:
                gerCli(g);
                break;
            case 3:
                gerServ(g);
                break;
            case 4:
                gerCond(g);
                break;
            case 5:
                gerTransp(g);
                break;
            case 6:
                verInfo(g);
                break;
            case 0:
                g.writeFile();
        }
    }
}

//----------------------------------------------------------
//                  MAIN
//----------------------------------------------------------

int main() {
   Gestao g;
   g.readFile();
   mainMenu(g);
   return 0;
}