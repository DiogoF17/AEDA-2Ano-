#ifndef PROJ1_CLIENTE_H
#define PROJ1_CLIENTE_H

#include <string>
#include <vector>
#include <iostream>
#include <algorithm>
#include <iomanip>

using namespace std;

/**
 * estrutura que garda o tempo em que foi inscrito
 */
struct Tempo{
    int mes; int ano; int dia;
    int minutos; int horas; int segundos;
};

/**
 * separa os ids dos pacotes transformando em vetor
 * @param ids string de ids passada
 * @return vetor de ids retornado
 */
vector<int> splitIds(string ids);

/**
 * retira os espacos a mais e coloca em carateres grandes o necessario
 * @param nome nome a formatar
 */
void formataNome(string &nome);

/**
 * classe que contem informacao sobre os clientes
 */
class Cliente {
protected:
    /**
     * diz qual o nome do cliente
     */
    string nome;
    /**
     * diz qual o nif do cliente
     */
    int nif;
    /**
     * diz quais os ids das habitacoes que adquiriu
     */
    vector<int> ids;
    /**
     * data e hora em que se inscreveu
     */
    Tempo inscricao;
public:
    /**
     * construtor por omissao da classe cliente
     */
    Cliente(){}
    /**
     * construtor da classe cliente
     */
    Cliente(string n):nome(n){}
    /**
     * altera o nome do cliente
     * @param n nome que e para ficar
     */
    void setNome(string n) ;
    /**
     * altera o nif do cliente
     * @param n nif que e para ficar
     */
    void setNif(string n);
    /**
     * altera os ids das habitacoes
     * @param ids ids que sao para ficar
     */
    void setIds(string ids);
    /**
     * retorna o nome do cliente
     * @return nome do cliente
     */
    string getNome() const;
    /**
     * altera o dia da inscricao
     * @param dia dia a alterar
     */
    void setDia(int dia);
    /**
     * altera o mes da inscricao
     * @param mes mes a alterar
     */
    void setMes(int mes);
    /**
     * altera o ano da inscricao
     * @param ano ano a alterar
     */
    void setAno(int ano);
    /**
     * altera os segundos da inscricao
     * @param segundo segundos a alterar
     */
    void setSegundo(int segundo);
    /**
     * altera os minutos da inscricao
     * @param minuto minutos a alterar
     */
    void setMinuto(int minuto);
    /**
     * altera a hora da inscricao
     * @param hora hora a alterar
     */
    void setHora(int hora);
    /**
    * retorna o dia da inscricao
    * @return dia da inscricao
    */
    int getDia() const;
    /**
     * retorna o mes da inscricao
     * @return mes da inscricao
     */
    int getMes() const;
    /**
     * retorna o ano da inscricao
     * @return ano da inscricao
     */
    int getAno() const;
    /**
     * retorna os segundos da inscricao
     * @return segundos da inscrico
     */
    int getSegundo() const;
    /**
     * retorna os minutos da inscricao
     * @return minutos da inscricao
     */
    int getMinuto() const;
    /**
     * retorna as horas da inscricao
     * @return horas da inscricao
     */
    int getHora() const;
    /**
     * retorna o nif do cliente
     * @return nif do cliente
     */
    int getNif() const;
    /**
     * retorna os ids das habitacoes
     * @return ids das habitacoes ods clientes
     */
    vector<int> getIds() const;
    /**
     * associa uma habitcao com o id indicado ao cliente
     * @param id id da habitacao a associar
     */
    void assocHabit(int id);
    /**
     * desassocia uma habitacao indicada com o id do cliente
     * @param id id da habitacao a desassociar
     */
    void desassociarHabit(int id);
    /**
     * diz se ja rxiste uma habitacao com aquele id
     * @param id id a verificar
     * @return verdade se ja existe e falso se nao existe
     */
    bool existe(int id);
    /**
     * pergunta ao utilizador qual o id do pacote a pagar
     * @return o id do pacote a pagar
     */
    int pagarMen();
    /**
     * mostra o cliente
     */
    void imprime() const;
    /**
     * diz se um cliente e igual a outro
     * @param c cliente a comparar
     * @return verdade se sao iguais falso caso contrario
     */
    bool operator==(const Cliente &c);
    /**
     * diz quando um cliete e menor que outro
     * @param c cliente a comparar
     * @return verdade se for menor que o usado no param c
     */
    bool operator<(const Cliente &c);
};

class AntigoCliente:public Cliente{
    /**
     * data e hora de quando saiu do condominio
     */
    Tempo saida;
public:
    /**
     * construtor por omissao
     */
    AntigoCliente(){}
    /**
     * altera o dia da saida
     * @param dia dia a alterar
     */
    void setDiaSaida(int dia);
    /**
     * altera o mes da saida
     * @param mes mes a alterar
     */
    void setMesSaida(int mes);
    /**
     * altera o ano da saida
     * @param ano ano a alterar
     */
    void setAnoSaida(int ano);
    /**
     * altera os segundos da saida
     * @param segundo segundos a alterar
     */
    void setSegundoSaida(int segundo);
    /**
     * altera os minutos da saida
     * @param minuto minutos a alterar
     */
    void setMinutoSaida(int minuto);
    /**
     * altera a hora da saida
     * @param hora hora a alterar
     */
    void setHoraSaida(int hora);
    /**
    * retorna o dia da saida
    * @return dia da saida
    */
    int getDiaSaida() const;
    /**
     * retorna o mes da inscricao
     * @return mes da saida
     */
    int getMesSaida() const;
    /**
     * retorna o ano da saida
     * @return ano da saida
     */
    int getAnoSaida() const;
    /**
     * retorna os segundos da saida
     * @return segundos da saida
     */
    int getSegundoSaida() const;
    /**
     * retorna os minutos da saida
     * @return minutos da saida
     */
    int getMinutoSaida() const;
    /**
     * retorna as horas da saida
     * @return horas da saida
     */
    int getHoraSaida() const;
    /**
     * imprime a informacao dos antigos clientes
     */
    void imprimeAnt() const;
};


#endif //PROJ1_CLIENTE_H
