//
// Created by Marcelo on 23/12/2019.
//

#include "Transportes.h"
#include "Cliente.h"

using namespace std;

Transportes::Transportes(string tipo, string destino, string pontoMprox, vector<Paragem> pontosParagem) {
    this->tipo=tipo;
    this->destino=destino;
    this->pontoMaisprox=pontoMprox;
    this->pontosParagem=pontosParagem;
    for (int i = 0; i <pontosParagem.size() ; i++) {
        paragensToDestino.push(pontosParagem.at(i));
    }
}

string Transportes::getTipo() const {
    return tipo;
}

string Transportes::getDestino() const {
    return destino;
}

string Transportes::getPontoMaisProx() const {
    return pontoMaisprox;
}

vector<Paragem> Transportes::getPontosParagem() const {
    return pontosParagem;
}

queue<Paragem> Transportes::getParagensToDestino() const {
    return paragensToDestino;
}

void Transportes::setDestino(string destino) {
    this->destino=destino;
}

void Transportes::setTipo(string t) {
    tipo=t;
}

void Transportes::setPontoMaisProx(string p) {
    pontoMaisprox=p;
}

void Transportes::setPontosParagem(vector<Paragem> pp) {
    pontosParagem=pp;
}

void Transportes::setParagensToDestino(queue<Paragem> ptd) {
    paragensToDestino=ptd;
}

bool Transportes::operator<(const Transportes&t1) const {
    return tempoToCondominio>t1.getTempoToCondominio();
}

int Transportes::getTempoToCondominio() const {
    return tempoToCondominio;
}

void Transportes::setTempoToCondominio(int t) {
    tempoToCondominio=t;
}

void Transportes::setTempoInicial(tm tempo){
    tempoDeInicio=tempo;
}

void Transportes::imprime() const {
    cout<<left<<setw(25)<<tipo
        <<left<<setw(25)<<destino
        <<left<<setw(35)<<pontoMaisprox
        <<left<<setw(25)<<to_string(tempoToCondominio)<<endl;
}

void Transportes::imprimePontosParagem() const {
    for (int i = 0; i <pontosParagem.size() ; ++i) {
        cout<<left<<setw(25)<<pontosParagem.at(i).local
            <<left<<setw(25)<<pontosParagem.at(i).tempo
            <<left<<setw(25);
        if (pontosParagem.at(i).ativa)
            cout<<"Sim"<<endl;
        else
            cout<<"Nao"<<endl;
    }
}

void Transportes::adicionarPontoDeParagem(int indice) {
    Paragem p1;
    string aux,aux1="";
    cout <<  "\n=========================================================";
    cout << "\n\t\tCRIAR PONTO DE PARAGEM";
    cout << "\n=========================================================" << "\n\n";
    cout<<"Ponto de Paragem: ";
    getline(cin,aux);
    formataNome(aux);
    if (verifyParagem(aux))
        throw runtime_error("Ja existe uma Paragem "+aux);
    p1.local=aux;
    cout<<"\nTempo de Espera (em min): ";
    getline(cin,aux);
    for (int i = 0; i < aux.length(); i++) {
        if (!isdigit(aux[i]) && aux[i] != ' ')
            throw invalid_argument("Erro no atributo ID!");
        else if(aux[i] != ' ')
            aux1 += string(1, aux[i]);
    }
    p1.tempo=stoi(aux);
    p1.ativa=true;
    cout<<endl;
    pontosParagem.insert(pontosParagem.begin()+(indice+1),p1);
}

bool Transportes::verifyParagem(string local) {
    for (int i = 0; i <pontosParagem.size() ; ++i) {
        if (pontosParagem.at(i).local==local)
            return true;
    }
    return false;
}

void Transportes::recalcularTempo() {
    int tmp=0;
    queue<Paragem> copia=paragensToDestino;
    while (1){
        while (!copia.empty()){
            if (copia.front().local==pontoMaisprox){
                tempoToCondominio=tmp;
                return;
            }
            if (copia.front().ativa)
                tmp+=copia.front().tempo;
            copia.pop();
        }
        for (int i = 0; i <pontosParagem.size() ; ++i) {
            if (pontosParagem.at(i).ativa)
                copia.push(pontosParagem.at(i));
        }
    }
}

void Transportes::atualizarParagensToDestino() {
    time_t now=time(NULL);
    tm tempoAtual =*localtime(&now);
    int temp=0;
    if (tempoDeInicio.tm_hour==tempoAtual.tm_hour) {
        if (tempoAtual.tm_min >= tempoDeInicio.tm_min)
            temp += tempoAtual.tm_min - tempoDeInicio.tm_min;
        else {
            temp += (60 - tempoDeInicio.tm_min) + tempoAtual.tm_min;
        }
    }else if (tempoDeInicio.tm_hour<tempoAtual.tm_hour){
        if (tempoAtual.tm_min >= tempoDeInicio.tm_min){
            temp+=60*(tempoAtual.tm_hour-tempoDeInicio.tm_hour);
            temp += tempoAtual.tm_min - tempoDeInicio.tm_min;
        }
        else {
            temp += (60 - tempoDeInicio.tm_min) + tempoAtual.tm_min;
        }
    }
    while (temp>=paragensToDestino.front().tempo){
        tempoDeInicio=tempoAtual;
        temp-=paragensToDestino.front().tempo;
        paragensToDestino.pop();
        if (paragensToDestino.empty()){
            for (int i = 0; i <pontosParagem.size() ; ++i) {
                if(pontosParagem.at(i).ativa)
                    paragensToDestino.push(pontosParagem.at(i));
            }
        }
    }
}

bool Transportes::verificarTodosAtivos() const {
    for (int i = 0; i <pontosParagem.size() ; ++i) {
        if(!pontosParagem.at(i).ativa)
            return false;
    }
    return true;
}

bool Transportes::verificarTodosDesativos() const {
    for (int i = 0; i <pontosParagem.size() ; ++i) {
        if(pontosParagem.at(i).ativa)
            return false;
    }
    return true;
}