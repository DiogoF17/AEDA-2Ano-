//
// Created by Utilizador on 18-10-2019.
//

#include "Habitacao.h"
#include <vector>
#include <ctype.h>

//--------------------------------------------------------
//                          AUXILIARES
//-------------------------------------------------------

/**
 * retira os espacos a mais e coloca em carateres grandes o necessario
 * @param nome nome a formatar
 */
void formataMorada(string &nome){
    vector<string> nomes;
    string aux = "";
    for(int i = 0; i < nome.length(); i++){
        if(isalpha(nome[i]))
            aux += string(1, nome[i]);
        else if(nome[i] == ' '){
            if(aux != "") {
                nomes.push_back(aux);
                aux = "";
            }
        }
    }
    if(aux != "")
        nomes.push_back(aux);
    if(nomes.empty())
        throw invalid_argument("O atributo morada nao pode estar vazio!");
    nome = "";
    for(int i = 0; i < nomes.size(); i++){
        if(nomes[i] != "de" && nomes[i] != "do" && nomes[i] != "da" && nomes[i] != "dos" && nomes[i] != "das"){
            for(int j = 0; j < nomes[i].length(); j++){
                if(j == 0)
                    nome +=string(1, toupper(nomes[i][j]));
                else nome += string(1, nomes[i][j]);
            }
        }
        else
            nome += nomes[i];
        if(i != nomes.size() - 1)
            nome += " ";
    }
}

//--------------------------------------------------
//                      HABITACAO
//-------------------------------------------------

void Habitacao::setTipo(std::string t) { tipo = t; }

void Habitacao::setMorada(std::string m) {
    for (int i = 0; i < m.length(); i++)
        if (!isalpha(m[i]) && m[i] != ' ')
            throw invalid_argument("Erro no atributo Morada!");
    formataMorada(m);
    morada = m;
}

void Habitacao::setId(std::string id){
    string aux = "";
    for (int i = 0; i < id.length(); i++) {
        if (!isdigit(id[i]) && id[i] != ' ')
            throw invalid_argument("Erro no atributo ID!");
        else if(id[i] != ' ')
            aux += string(1, id[i]);
    }
    if(aux == "")
        throw invalid_argument("Erro no atributo ID!");
    this->id = stoi(aux);
}

void Habitacao::setValorBase(std::string vB) {
    string aux = "";
    for (int i = 0; i < vB.length(); i++){
        if (!isdigit(vB[i]) && vB[i] != '.' && vB[i] != ' ')
            throw invalid_argument("Erro no atributo Valor Base!");
        else if(vB[i] != ' ')
            aux += string(1, vB[i]);
    }
    if(aux == "")
        throw invalid_argument("Erro no atributo Valor Base!");
    valorBase = std::stod(aux);
}

void Habitacao::setAreaHabitacional(std::string aA) {
    string aux = "";
    for (int i = 0; i < aA.length(); i++){
        if (!isdigit(aA[i]) && aA[i] != '.' && aA[i] != ' ')
            throw invalid_argument("Erro no atributo Area Habitacional!");
        else if(aA[i] != ' ')
            aux += string(1, aA[i]);
    }
    if(aux == "")
        throw invalid_argument("Erro no atributo Area Habitacional!");
    areaHabitacional = std::stod(aux);
}

void Habitacao::setPago(string p) {
    string aux = "";
    for (int i = 0; i < p.length(); i++){
        if (!isalpha(p[i]) && p[i] != ' ')
            throw invalid_argument("Erro no atributo Pago!");
        else if(p[i] != ' ')
            aux += string(1, p[i]);
    }
    if (aux == "sim")
        pago = true;
    else if(aux == "nao")
        pago = false;
    else
        throw invalid_argument("Erro no atributo Pago!");
}

void Habitacao::setDisponibilidade(string d){
    string aux = "";
    for (int i = 0; i < d.length(); i++){
        if (!isalpha(d[i]) && d[i] != ' ')
            throw invalid_argument("Erro no atributo Piscina!");
        else if(d[i] != ' ')
            aux += string(1, d[i]);
    }
    if(aux == "sim")
        disponivel = true;
    else if(aux == "nao")
        disponivel = false;
    else
        throw invalid_argument("Erro no atributo Piscina!");
}

string Habitacao::getTipo() const{return tipo;}

int Habitacao::getId()const{return id;}

string Habitacao::getMorada() const{return morada;}

double Habitacao::getValorBase() const{return valorBase;}

double Habitacao::getAreaHabitacional() const{return areaHabitacional;}

bool Habitacao::getDisponivel() const{return disponivel;}

bool Habitacao::getPago() const{return pago;}

double Habitacao::getMensalidade() const{ return mensalidade;}

void Habitacao::setProprietario(string p){proprietario = p;}

string Habitacao::getProprietario() const{return proprietario;}

//-----------------------------------------------------------------
//              VIVENDA
//-----------------------------------------------------------------

void Vivenda::calcImposto() {
    double valor = valorBase;
    if (piscina == true) {
        if (areaExterior <= 500)
            valor = valor + 0.28 * valor;
        else if (areaExterior > 500 && areaExterior <= 1000)
            valor = valor + 0.45 * valor;
        else if (areaExterior > 1000 & areaExterior <= 2000)
            valor = valor + 0.55 * valor;
        else
            valor = valor + valor * 0.70;
    }
    else {
        if (areaExterior <= 500)
            valor = valor + 0.08 * valor;
        else if (areaExterior > 500 && areaExterior <= 1000)
            valor = valor + 0.20 * valor;
        else if (areaExterior > 1000 & areaExterior <= 2000)
            valor = valor + 0.35 * valor;
        else
            valor = valor + valor * 0.50;
    }
    mensalidade = valor;
}

void Vivenda::setAreaExterior(std::string aE) {
    string aux = "";
    for (int i = 0; i < aE.length(); i++) {
        if (!isdigit(aE[i]) && aE[i] != '.' && aE[i] != ' ')
            throw invalid_argument("Erro no atributo Area Exterior!");
        else if(aE[i] != ' ')
            aux += string(1, aE[i]);
    }
    if(aux == "")
        throw invalid_argument("Erro no atributo Area Exterior!");
    areaExterior = std::stod(aux);
    calcImposto();
}

void Vivenda::setPiscina(std::string p) {
    string aux = "";
    for (int i = 0; i < p.length(); i++){
        if (!isalpha(p[i]) && p[i] != ' ')
            throw invalid_argument("Erro no atributo Piscina!");
        else if(p[i] != ' ')
            aux += string(1, p[i]);
    }
    if (aux == "sim")
        piscina = true;
    else if(aux == "nao")
        piscina = false;
    else
        throw invalid_argument("Erro no atributo Piscina!");
    calcImposto();
}

double Vivenda::getAreaExterior() const{return areaExterior;}

bool Vivenda::getPiscina() const{return piscina;}

void Vivenda::imprime() const{
    /*cout << left << setw(5) << "Id"
         << setw(25) << "Morada"
         << setw(15) << "A.Habitacional"
         << setw(25) << "Proprietario"
         << setw(11) << "A.Exterior"
         << setw(8) << "Piscina"
         << setw(12) << "Mensalidade"
         << setw(11) << "Disponivel"
         << setw(5) << "Pago";*/
     cout << left << setw(5) << id
             << setw(25) << morada
             << setw(15) << areaHabitacional
             << setw(25) << proprietario
             << setw(11) << areaExterior;
     if(piscina == true)
         cout << left << setw(8) << "sim";
     else
         cout << left << setw(8) << "nao";
     cout << setw(12) << mensalidade;
    if(disponivel == true)
        cout << left << setw(11) << "sim";
    else
        cout << left << setw(11) << "nao";
    if(pago == true)
        cout << " sim";
    else
        cout << " nao";
    cout << endl;
}

//--------------------------------------------------------
//                  APARTAMENTO
//----------------------------------------------------------

void Apartamento::calcImposto() {
    double valor = valorBase;
    if (piso >= 0 && piso <= 3) {
        if (tipologia == "T1")
            valor = valor + 0.05 * valor;
        else if (tipologia == "T2")
            valor = valor + 0.1 * valor;
        else
            valor = valor + 0.25 * valor;
    }
    else {
        if (tipologia == "T1")
            valor = valor + 0.15 * valor;
        else if (tipologia == "T2")
            valor = valor + 0.25 * valor;
        else
            valor = valor + 0.40 * valor;
    }
    mensalidade = valor;
}

void Apartamento::setTipologia(std::string t) {
    string aux = "";
    for (int i = 0; i < t.length(); i++) {
        if (!isalpha(t[i]) && !isdigit(t[i]) && t[i] != '+' && t[i] != ' ')
            throw invalid_argument("Erro no atributo Tipologia!");
    else if(t[i] != ' ')
        aux += string(1, t[i]);
    }
    if(aux == "")
        throw invalid_argument("Erro no atributo Tipologia!");
    tipologia = aux;
    calcImposto();
}

void Apartamento::setPiso(std::string p) {
    string aux = "";
    for (int i = 0; i < p.length(); i++){
        if (!isdigit(p[i]) && p[i] != '.' && p[i] != ' ')
            throw invalid_argument("Erro no atributo Piso!");
        else if(p[i] != ' ')
            aux += string(1, p[i]);
    }
    if(aux == "")
        throw invalid_argument("Erro no atributo Piso!");
    piso = stoi(aux);
    calcImposto();
}

int Apartamento::getPiso() const{ return piso;}

string Apartamento::getTipologia() const{ return  tipologia;}

void Apartamento::imprime() const{
    cout << left << setw(5) << id;
    cout << " " << setw(25) << morada;
    cout << " " << setw(15) << areaHabitacional;
    cout << " " <<  setw(25) << proprietario;
    cout << " " << setw(10) << tipologia;
    cout << " " << setw(5) << piso;
    cout << " " << setw(12) << mensalidade;
    if(disponivel == true)
        cout << " " << setw(11) << "sim";
    else
        cout << " " << setw(11) << "nao";
    if(pago == true)
        cout << " sim";
    else
        cout << " nao";
    cout << endl;
}

