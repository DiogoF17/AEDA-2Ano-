//
// Created by Utilizador on 11-11-2019.
//

#ifndef PROJ1_SERVICOS_H
#define PROJ1_SERVICOS_H


#include <string>
#include <ctime>
#include <vector>

using namespace std;

/**
 * guarda os dados necessarios para apresentar toda a informação acerca do servico prestado
 */
struct Info_Servico{
    /**
     * estado a que se encontra o servico("a decorrer", "cancelado","terminado")
     */
    string estado;
    /**
     * nome do cliente a qual esta a ser prestado o servico
     */
    string cliente;
    /**
     * tipo de servico prestado
     */
    string servico;
    /**
     * id da habitacao no qual esta a ser prestado o servico
     */
    int id;
    /**
     * data e hora de quando o servico e inicializado
     */
    tm tempo_incial;
    /**
     * data e hora de quando o servico e terminado ou cancelado
     */
    tm tempo_final;
};

/**
 * classe que contem informcao sobre os servicos
 */
class Servicos{
public:
    /**
     * construtor por omissao da classe Servicos
     */
    Servicos(){};
    /**
     * construtor da classe servicos
     * @param servico servico prestado
     * @param prestador nome da empresa que presta o servico
     * @param preco_mensal preco mensal imposto pelo servico
     */
    Servicos(string servico, string prestador, float preco_mensal);
    /**
     * retorna o tipo de servico prestado
     * @return servico prestado
     */
    string getservico() const;
    /**
     * retorna o nome do prestador do servico
     * @return prestador do servicos
     */
    string getprestador() const;
    /**
     * retorna o numero de ocorrencias
     * @return numero de ocorrencias do servico
     */
    int getnumocorrencias() const;
    /**
     * verifica se o vetor de info servico esta vazio
     * @return true se estiver vazio, false caso contrario
     */
    bool historico_empty(){return historico_servicos.empty();}
    /**
     * retorna um vetor de Info_servico que contem o historico de servicos prestados
     * @return todos servicos prestados ate ao momento
     */
    vector<Info_Servico> getHistorico() const{ return historico_servicos;}
    /**
     * retorna o preco mensal imposto pelo servico
     * @return preco mensal do servico
     */
    float getprecomensal() const;
    /**
     * retorna a disponibilidade do servico
     * @return true se estiver disponivel , false caso contrario
     */
    bool getdisponibilidade() const;
    /**
     * alterar o tipo de servico que o prestador realiza
     * @param servico novo servico prestado
     */
    void setservico(string servico);
    /**
     * alterar prestador do servico
     * @param prestador novo nome do prestador do servicos
     */
    void setprestador(string prestador);
    /**
     * alterar a disponibilidade
     * @param disp true se estiver disponivel, false caso contrario
     */
    void setdisponibilidade(bool disp);
    /**
     * alterar o numero de ocorrencias
     * @param num_ocorr novo numero de ocorrencias
     */
    void setnumOcorrencias(int num_ocorr);
    /**
     * alterar o preco mensal do servico
     * @param preco novo preco imposto pelo servico
     */
    void setprecomensal(string preco);
    /**
     * alterar o preco mensal do servico
     * @param preco novo preco imposto pelo servico
     */
    void setprecomensal(float preco);
    /**
     * atualiza o historico do servico com os servicos prestados numa utilizacao anterior do programa
     * @param temp struct utilizada para guardar os dados dos servicos prestados
     */
    void setRegisto(Info_Servico temp);
    /**
     * inicia um servico
     * @param id id da habitacao no qual se prentende realizar o servico
     * @param cliente nome do cliente que pediu o servico
     */
    void startservico(int id,string cliente);
    /**
     * cancela o servico que esta a ser prestado
     */
    void cancelservico();
    /**
     * termina o servico que esta a ser prestado
     */
    void finishservico();
    /**
     * imprime o historico dos servico prestados numa determinada habitacao
     * @param id id da habitacao
     */
    void printhistoricobylocal(int id);
    /**
     * imprime o historico dos servicos que estao num determinado estado
     * @param estado estado a que o servico se encontra
     */
    void printhistoricobyestado(string estado);
    /**
     * imprime o historico dos servicos prestados ao cliente
     * @param cliente nome do cliente
     */
    void printhistoricobycliente(string cliente);
    /**
     * imprime os dados do servico(servico,prestador,preco mensal, numero de ocorrencias, disponibilidade)
     */
    void imprime() const;

private:
    /**
     * tipo do servico prestado p.e: limpeza
     */
    string servico;
    /**
     * nome da empresa que presta o servico
     */
    string prestador;
    /**
     * numero de vezes que o servico foi solicitado e terminado com sucesse, exclui os cancelamentos
     */
    int num_ocorrencias;
    /**
     * preco que o servico cobra por mes ao condominio
     */
    float preco_mensal;
    /**
     * indica se o servico esta disponivel
     */
    bool disponivel;
    /**
     * vetor com todos os servicos prestados as habitacoes do condominio
     */
    vector<Info_Servico> historico_servicos;
};


#endif //PROJ1_SERVICOS_H
