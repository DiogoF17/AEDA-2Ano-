#include "Cliente.h"
#include <vector>
#include <string>

using namespace std;

//--------------------------------------------------------------
//                  AUXILIARES
//--------------------------------------------------------------
vector<int> splitIds(string ids) {
    vector<int> ret;
    string aux = "";
    if(ids == "-")
        return ret;
    for(int i = 0; i < ids.length(); i++){
        if(ids[i] == ';') {
            if (aux != " ") {
                ret.push_back(stoi(aux));
                aux = "";
            }
        }
        else if(isdigit(ids[i]) || ids[i] == ' ') {
            if(isdigit(ids[i]))
                aux += string(1, ids[i]);
        }
        else
            throw logic_error("Erro no atributo IDS!");
    }
    ret.push_back(stoi(aux));
    return ret;
}

void formataNome(string &nome){
    vector<string> nomes;
    string aux = "";
    for(int i = 0; i < nome.length(); i++){
        if(isalpha(nome[i]))
            aux += string(1, nome[i]);
        else if(nome[i] == ' '){
            if(aux != "") {
                nomes.push_back(aux);
                aux = "";
            }
        }
    }
    if(aux != "")
        nomes.push_back(aux);
    if(nomes.empty())
        throw logic_error("O atributo nome nao pode estar vazio!");
    nome = "";
    for(int i = 0; i < nomes.size(); i++){
        if(nomes[i] != "de" || nomes[i] != "do" || nomes[i] != "da" || nomes[i] != "dos" || nomes[i] != "das"){
            for(int j = 0; j < nomes[i].length(); j++){
                if(j == 0)
                    nome +=string(1, toupper(nomes[i][j]));
                else nome += string(1, nomes[i][j]);
            }
        }
        else
            nome += nomes[i];
        if(i != nomes.size() - 1)
            nome += " ";
    }
}

//----------------------------------------------------------
//                  CLIENTE
//---------------------------------------------------------

void Cliente::setNome(string n) {
    for (int i = 0; i < n.length(); i++)
        if (!isalpha(n[i]) && n[i] != ' ')
            throw logic_error("Erro ao criar este cliente no atributo Nome!");
    formataNome(n);
    nome = n;
}

void Cliente::setNif(string n) {nif = stoi(n);}

void Cliente::setIds(string ids){
    if(ids != "-")
        this->ids = splitIds(ids);
}

string Cliente::getNome() const{return nome;}

int Cliente::getNif() const{return nif;}

vector<int> Cliente::getIds() const{return ids;}

void Cliente::assocHabit(int id){ids.push_back(id);}

void Cliente::desassociarHabit(int id){
    int ind = 0;
    for(int i = 0; i < ids.size(); i++) {
        if (ids[i] == id)
            ind = i;
    }
    ids.erase(ids.begin() + ind);
}

bool Cliente::existe(int id){
    sort(ids.begin(), ids.end());
    return binary_search(ids.begin(), ids.end(), id);
}

int Cliente::pagarMen(){
    string aux;
    cout << "Introduza o ID do pacote:", getline(cin, aux);
    vector<int>::iterator it = find(ids.begin(), ids.end(), stoi(aux));
    if(it == ids.end())
        throw logic_error("O cliente " + nome + " nao possui nenhuma habitacao com o ID: " + aux);
    return *it;
}

void Cliente::imprime() const{
    cout << "Nome......................: " << nome
         << "\nNif.......................: " << nif
         << "\nHabitacoes Adquiridas(Ids): ";
    if(ids.size() == 0)
        cout << "-";
    else {
        for (int i = 0; i < ids.size(); i++)
            if(i != ids.size() - 1)
                cout << ids[i] << " ; ";
            else
                cout << ids[i];
    }
}

bool Cliente::operator==(const Cliente &c){
    return nome == c.nome;
}

bool Cliente::operator<(const Cliente &c){
    return nome < c.nome;
}

