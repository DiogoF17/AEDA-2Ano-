#ifndef PROJ1_HABITACAO_H
#define PROJ1_HABITACAO_H

#include <string>
#include <ctype.h>
#include <stdexcept>
#include <iostream>

using namespace std;

void formataMorada(string &nome);

class Habitacao {
protected:
    /**
     * diz se e apartamento ou vivenda
     */
    string tipo;
    /**
     * id da habitacao
     */
    int id;
    /**
     * morada da habitacao
     */
    string morada;
    /**
     * valor base da habitacao
     */
    double valorBase;
    /**
     * area habitacional da habitacao
     */
    double areaHabitacional;
    /**
     * diz se uma habitacao esta ocupada ou livre para ser habitada
     */
    bool disponivel;
    /**
     * diz se a mensalidade foi paga
     */
    bool pago;
    /**
     * diz qual a mensalidade
     */
    double mensalidade;
public:
    /**
     * construtor por omissao da classe habitacao
     */
    Habitacao(){}
    /**
     * construtor da classe habitacao
     * @param i
     */
    Habitacao(int i):id(i){}
    /**
     * altera o tipo de habitacao(Apartamento ou Vivenda)
     * @param t tipo de habitacao a ficar
     */
    void setTipo(std::string t);
    /**
     * imprime a habitacao
     */
    virtual void imprime() const = 0;
    /**
     * altera a morada
     * @param m morada a ficar
     */
    void setMorada(std::string m);
    /**
     * altera o id da habitacao
     * @param id id a ficar
     */
    void setId(std::string id);
     /**
      * altera o valor base da habitacao
      * @param vB valor base a ficar
      */
    void setValorBase(std::string vB);
    /**
     * altera a area habitacional
     * @param aA area habitacional a ficar
     */
    void setAreaHabitacional(std::string aA);
    /**
     * altera o atributo pago
     * @param p pago(true) ou nao(false)
     */
    void setPago(string p);
    /**
     * altera a disponibilidade
     * @param d disponivel(true) ou indisponivel(false)
     */
    void setDisponibilidade(string d);
    /**
     * retorna o tipo de habitacao
     * @return tipo de habitacao
     */
    string getTipo() const;
    /**
     * retorna o id
     * @return id da habitacao
     */
    int getId()const;
    /**
     * retorna a morada da habitacao
     * @return morada da habitacao
     */
    string getMorada() const;
    /**
     * retorna o valor base
     * @return valor base da habitacao
     */
    double getValorBase() const;
    /**
     * retorna a area habitaconal
     * @return area habitacional
     */
    double getAreaHabitacional() const;
    /**
     * retorna a disponibilidade
     * @return true(disponivel), false(indisponivel)
     */
    bool getDisponivel() const;
    /**
     * retorna a dizer se ta pago
     * @return true(pago), false(nao esta pago)
     */
    bool getPago() const;
    /**
     * retorna a mensalidade
     * @return mensalidade da habitacao
     */
    double getMensalidade() const;
    /**
     * calcula a mensalidade da habitacao
     */
    virtual void calcImposto() = 0;
};

class Vivenda:public Habitacao{
    /**
     * area exterior da vivenda
     */
    double areaExterior;
    /**
     * diz se tem piscina
     */
    bool piscina;
public:
    /**
     * construtor por omissao da classe vivenda
     */
    Vivenda(){}
    /**
     * valcula a mensalidade da vivenda
     */
    void calcImposto();
    /**
     * altera a area exterior do vivenda
     * @param aE area exterior a alterar
     */
    void setAreaExterior(std::string aE);
    /**
     * altera para true(tem piscina)ou false(nao tem piscina)
     * @param p true(tem piscina)ou false(nao tem piscina)
     */
    void setPiscina(std::string p);
    /**
     * retorna a area exterior
     * @return area exterior da vivenda
     */
    double getAreaExterior() const;
    /**
     * retorna a piscina
     * @return true(tem piscina), false(nao tem piscina)
     */
    bool getPiscina() const;
    /**
     * imprime a vivenda
     */
    void imprime() const;
};

class Apartamento:public Habitacao{
    /**
     * diz qual o piso em que esta situado
     */
    int piso;
    /**
     * diz qual a sua tipologia
     */
    string tipologia;
public:
    Apartamento(){}
    /**
     * calcula a mensalidade do apartamento
     */
    void calcImposto();
    /**
     * altera a tipologia do apartamento
     * @param t tipologia a alterar
     */
    void setTipologia(std::string t);
    /**
     * altera o piso do apartamento
     * @param p pisdo do apartamento a alterar
     */
    void setPiso(std::string p);
    /**
     * retorna o piso
     * @return piso do apartamento
     */
    int getPiso() const;
    /**
     * retorna a tipologia
     * @return tipologia do apartamento
     */
    string getTipologia() const;
    /**
     * imprime o apartamento
     */
    void imprime() const;
};

#endif //PROJ1_HABITACAO_H
