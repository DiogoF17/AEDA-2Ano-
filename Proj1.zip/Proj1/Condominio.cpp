#include "Condominio.h"
#include <fstream>
#include <iomanip>
#include "Servicos.h"

/**
 * funcao usada na ordenacao de habitacoes com base no ID
 * @param h1 apontador para uma habitacao
 * @param h2 apontador para uma habitacao
 * @return retorna se um id e menor que outro
 */
bool compId(Habitacao *h1, Habitacao *h2){
    return h1->getId() < h2->getId();
}

/**
 * funcao usada na ordenacao de habitacoes com base na area habitacional
 * @param h1 apontador para uma habitacao
 * @param h2 apontador para uma habitacao
 * @return retorna se uam area e menor que outra
 */
bool compAA(Habitacao *h1, Habitacao *h2){
    return h1->getAreaHabitacional() < h2->getAreaHabitacional();
}

void Condominio::readFile(){
    //---------------------------
    string aux;
    ifstream entrada;
    cout << "Nome do Ficheiro: ", std::cin >> aux;
    entrada.open(aux);
    //verifica se houve algum erro ao tentar abrir o ficheiro
    while(std::cin.fail() || !entrada.is_open()){
        if(std::cin.fail()) {
            std::cin.clear();
            std::cin.ignore(1000, '\n');
        }
        else
            std::cin.ignore(1000, '\n');
        std::cout << "Erro! Nome do Ficheiro: ", std::cin >> aux;
        entrada.open(aux);
    }
    nomeFicheiro = aux;
    //----------------------------
    //Le o ficheiro do condominio
    getline(entrada, aux);  //le palavra Habitacoes
    getline(entrada, aux); // le palavra seguinte a habitacoes
    while(aux != "CLIENTES") { // se a palvra nao for servicos
        if(aux == "Vivenda"){
            Vivenda *v = new Vivenda();
            (*v).setTipo(aux);
            getline(entrada, aux), (*v).setId(aux);
            getline(entrada, aux), (*v).setMorada(aux);
            getline(entrada, aux), (*v).setValorBase(aux);
            getline(entrada, aux), (*v).setAreaHabitacional(aux);
            getline(entrada, aux), (*v).setAreaExterior(aux);
            getline(entrada, aux), (*v).setPiscina(aux);
            getline(entrada, aux), (*v).setDisponibilidade(aux);
            getline(entrada, aux); v->setProprietario(aux);
            v->setPago("nao"); v->calcImposto();
            habitacoes.push_back(v);
        }
        else{
            Apartamento *a = new Apartamento();
            (*a).setTipo(aux);
            getline(entrada, aux), (*a).setId(aux);
            getline(entrada, aux), (*a).setMorada(aux);
            getline(entrada, aux), (*a).setValorBase(aux);
            getline(entrada, aux), (*a).setAreaHabitacional(aux);
            getline(entrada, aux), (*a).setPiso(aux);
            getline(entrada, aux), (*a).setTipologia(aux);
            getline(entrada, aux), (*a).setDisponibilidade(aux);
            getline(entrada, aux); a->setProprietario(aux);
            (*a).setPago("nao"); a->calcImposto();
            habitacoes.push_back(a);
        }
        getline(entrada, aux);
    }
    getline(entrada, aux); // le palavra seguinte a clientes
    while(aux != "SERVICOS") {
        Cliente *cl = new Cliente();
        cl->setNome(aux);
        getline(entrada, aux), cl->setNif(aux);
        getline(entrada, aux), cl->setIds(aux);
        clientes.push_back(*cl);
        getline(entrada, aux);
    }
    while(getline(entrada, aux)) { //nome do servico
        Servicos *s1= new Servicos();
        s1->setservico(aux);
        getline(entrada, aux); s1->setprestador(aux);
        getline(entrada, aux);
        s1->setprecomensal(aux);
        s1->setdisponibilidade(true);
        s1->setnumOcorrencias(0);
        servicos.push_back(*s1);
    }
    update = false;
    entrada.close();
    //-------------------------

}

void Condominio::writeFile(){
    char res;
    if(update == true){//o ficheiro foi alterado
        std::cout << "\nXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n";
        std::cout << "Pretende guardar as alteracoes efetuadas('s'\\'n'): ", std::cin >> res;
        while(std::cin.fail() || (res!= 's' && res!='n')){
            if(std::cin.fail()){
                std::cin.clear();
                std::cin.ignore(1000, '\n');
            }
            std::cout << "Erro! Pretende guardar as alteracoes efetuadas('s'\\'n'): ", std::cin >> res;
        }
        if(res == 's'){
            std::ofstream saida1;
            saida1.open(nomeFicheiro);
            saida1 << "HABITACOES";
            for(int i = 0; i < habitacoes.size(); i++){
                if(habitacoes[i]->getTipo() == "Vivenda") {
                    Vivenda *v = dynamic_cast<Vivenda *> (habitacoes[i]);
                    saida1 << endl << v->getTipo()
                           << std::endl << v->getId()
                           << std::endl << v->getMorada()
                           << std::endl << v->getValorBase()
                           << std::endl << v->getAreaHabitacional()
                           << std::endl << v -> getAreaExterior()
                           << std::endl << v -> getProprietario();
                    if(v -> getPiscina() == true)
                        saida1 << "\nsim";
                    else
                        saida1 << "\nnao";
                    if(v -> getDisponivel() == true)
                        saida1 << "\nsim";
                    else
                        saida1 << "\nnao";
                }
                else{
                    Apartamento *a = dynamic_cast<Apartamento *> (habitacoes[i]);
                    saida1 << endl << a->getTipo()
                           << std::endl << a->getId()
                           << std::endl << a->getMorada()
                           << std::endl << a->getValorBase()
                           << std::endl << a->getAreaHabitacional()
                           << std::endl << a -> getPiso()
                           << std::endl << a -> getTipologia()
                            << std::endl << a -> getProprietario();
                    if(a -> getDisponivel() == true)
                        saida1 << "\nsim";
                    else
                        saida1 << "\nnao";
                }
            }
            saida1 << std::endl << "CLIENTES";
            for(int i = 0; i < clientes.size(); i++){
                saida1 << endl << clientes[i].getNome()
                       << std::endl << clientes[i].getNif();
                if(clientes[i].getIds().size() == 0)
                    saida1 << "\n-";
                else{
                    vector<int> ids = clientes[i].getIds();
                    saida1 << endl;
                    for(int j = 0; j < ids.size(); j++){
                        if(j == ids.size() - 1)
                            saida1 << ids[j];
                        else
                            saida1 << ids[j] << "; ";
                    }
                }

            }
            saida1 << "\nSERVICOS";
            for(int i = 0; i < servicos.size(); i++){
                saida1 << "\n" << servicos[i].getservico()
                << "\n" << servicos[i].getprestador()
                << "\n" << servicos[i].getprecomensal();
            }
            saida1.close();
            std::cout << "\nAs alteracoes foram gravadas com sucesso!\n\n";
            exit(1);
        }
        else
            exit(1);
    }
    else
        exit(1);
}

void Condominio::imprimeTodosClientes(int op) const{
    vector<Cliente> a = clientes;
    if(op == 1)
      sort(a.begin(), a.end());
    for(int i = 0; i < a.size(); i++) {
        a[i].imprime();
        cout << endl << endl;
    }
}

void Condominio::imprimeCliente() const{
    string aux;
    cin.ignore(1000, '\n');
    cout << "Introduza o nome do Cliente:", getline(cin, aux);
    formataNome(aux);
    int ind = -1;
    for(int i = 0; i < clientes.size(); i++){
        if(clientes[i].getNome() == aux)
            ind = i;
    }
    if(ind == -1)
        throw runtime_error("Nao existe nenhum cliente com o nome: " + aux);
    else
        clientes[ind].imprime();
}

void Condominio::verTodosHabitacoes(int op) const{
    vector<Habitacao*> h = habitacoes;
    if(op == 1)
        sort(h.begin(), h.end(), compId);
    else if(op == 2)
        sort(h.begin(), h.end(), compAA);
    for (int i = 0; i < h.size(); i++)
        h[i]->imprime();
}

void Condominio::verHabitacaoEsp()const{
    string aux, aux1 = "";
    cin.ignore(1000, '\n');
    cout << "Introduza o ID da Habitacao:", getline(cin, aux);
    for (int i = 0; i < aux.length(); i++) {
        if (!isdigit(aux[i]) && aux[i] != ' ')
            throw invalid_argument("Erro no atributo ID!");
        else if(aux[i] != ' ')
            aux1 += string(1, aux[i]);
    }
    int ind=-1;
    for(int i = 0; i < habitacoes.size(); i++){
        if(habitacoes[i]->getId() == stoi(aux1)){
            ind = i;
            break;
        }
    }
    if(ind == -1)
        throw runtime_error("Nao existe nenhuma habitacao com o id: " + aux1);
    else{
        cout << endl;
        habitacoes[ind]->imprime();
    }
}

void Condominio::addCliente(Cliente &c){
    clientes.push_back(c);
    cout << "\nCliente adicionado com sucesso!\n\n";
    clientes[clientes.size() - 1].imprime();
}

void Condominio::alterarCliente(){
    imprimeTodosClientes(0);
    string aux;
    cin.ignore(1000, '\n');
    cout << "Introduza o nome do cliente:", getline(cin, aux);
    formataNome(aux);
    int ind=-1;
    for(int i = 0; i < clientes.size(); i++){
        if(clientes[i].getNome() == aux){
            ind = i;
            break;
        }
    }
    if(ind == -1)
        throw runtime_error("Nao existe nenhum cliente com o nome: " + aux);
    std::cout << "\n\t\tPARAMETRO A ALTERAR\n\n"
              << "1) Nome;\n2) Nif;";
    int param = Opcao(false, 2);
    cin.ignore(1000, '\n');
    switch (param) {
        case 1:
            std::cout << "\nIntroduza o novo nome:", getline(std::cin, aux);
            clientes[ind].setNome(aux);
            break;
        case 2:
            std::cout << "\nIntroduza o novo NIF:", getline(std::cin, aux);
            verifyNif(aux);
            clientes[ind].setNif(aux);
            break;
    }
    cout << "\nHabitacao alterada com sucesso!\n\n";
    clientes[ind].imprime();
}

void Condominio::removerCliente(){
    imprimeTodosClientes(0);
    string aux;
    cin.ignore(1000, '\n');
    cout << "Introduza o nome do Cliente:", getline(cin, aux);
    formataNome(aux);
    Cliente c(aux);
    vector<Cliente>::iterator it = find(clientes.begin(), clientes.end(), c);
    if(it == clientes.end())
        throw runtime_error("Nao existe nenhum cliente com o nome: " + aux);
    clientes.erase(it);
    cout << "\nCliente removido com sucesso!";
}

void Condominio::associarHabit(){
    imprimeTodosClientes(0);
    string aux;
    cin.ignore(1000, '\n');
    cout << "Introduza o nome do Cliente:", getline(cin, aux);
    formataNome(aux);
    Cliente c(aux);
    vector<Cliente>::iterator it = find(clientes.begin(), clientes.end(), c);
    if(it == clientes.end())
        throw runtime_error("Nao existe nenhum cliente com o nome: " + aux);
    vector<int> disp;
    cout << endl;
    for(int i = 0; i < habitacoes.size(); i++){
        if(habitacoes[i]->getDisponivel() == true) {
            disp.push_back(habitacoes[i]->getId());
            habitacoes[i]->imprime();
        }
    }
    string id;
    cout << "Introduza o ID do pacote que pretende associar:", getline(cin, id);
    sort(disp.begin(), disp.end());
    bool existe = binary_search(disp.begin(), disp.end(), stoi(id));
    if(existe == false)
        throw runtime_error("Nao existe nenhum pacote com o id: " + id);
    it->assocHabit(stoi(id));
    for(int i = 0; i < habitacoes.size(); i++){
        if(habitacoes[i]->getId() == stoi(id)){
            habitacoes[i]->setDisponibilidade("nao");
            habitacoes[i]->setProprietario(c.getNome());
        }
    }
    cout << "Habitacao adquirida com sucesso!\n\n";
    it->imprime();
}

void Condominio::desassociarHabit(){
    imprimeTodosClientes(0);
    string aux;
    cin.ignore(1000, '\n');
    cout << "Introduza o nome do Cliente:", getline(cin, aux);
    formataNome(aux);
    Cliente c(aux);
    vector<Cliente>::iterator it = find(clientes.begin(), clientes.end(), c);
    if(it == clientes.end())
        throw runtime_error("Nao existe nenhum cliente com o nome: " + aux);
    vector<int> ids = it->getIds();
    cout << endl;
    for(int i = 0; i < habitacoes.size(); i++){
        if(it->existe(habitacoes[i]->getId()))
            habitacoes[i]->imprime();
    }
    string id;
    cout << "Introduza o ID da Habitacao:", getline(cin, id);
    bool existe = it->existe(stoi(id));
    if(existe == false)
        throw runtime_error("Nao existe nenhum pacote com o id: " + id);
    it->desassociarHabit(stoi(id));
    for(int i = 0; i < habitacoes.size(); i++){
        if(habitacoes[i]->getId() == stoi(id)) {
            habitacoes[i]->setDisponibilidade("sim");
            habitacoes[i]->setPago("nao");
            habitacoes[i]->setProprietario("-");
            break;
        }
    }
    cout << "\nHabitacao desassociada com sucesso!\n\n";
    it->imprime();
}

void Condominio::addHabitacao(Habitacao *h){
    habitacoes.push_back(h);
    cout << "\nHabitacao adicionada com sucesso!\n\n";
    habitacoes[habitacoes.size() - 1]->imprime();
}

void Condominio::alterarHabitacao(){
    verTodosHabitacoes(0);
    string aux, aux1 = "";
    cin.ignore(1000, '\n');
    cout << "Introduza o ID do pacote:", getline(cin, aux);
    for (int i = 0; i < aux.length(); i++) {
        if (!isdigit(aux[i]) && aux[i] != ' ')
            throw invalid_argument("Erro no atributo ID!");
        else if(aux[i] != ' ')
            aux1 += string(1, aux[i]);
    }
    int ind=-1;
    for(int i = 0; i < habitacoes.size(); i++){
        if(habitacoes[i]->getId() == stoi(aux1)){
            ind = i;
            break;
        }
    }
    if(ind == -1)
        throw runtime_error("Nao existe nenhuma habitacao com o id " + aux);
    std::cout << "\n\t\tPARAMETRO A ALTERAR\n\n"
              << "1) ID;\n2) Morada;\n3) Valor Base;\n4) Area Habitacional;";
    if(habitacoes[ind]->getTipo() == "Vivenda")
        std::cout << "\n5) Area Exterior;\n6) Piscina;\n7) Pago;\n8) Disponivel;";
    else
        std::cout << "\n5) Piso;\n6) Tipologia;\n7) Pago;\n8) Disponivel;";
    int param = Opcao(false, 8);
    cin.ignore(1000, '\n');
    if (habitacoes[ind]->getTipo() == "Vivenda") {
        Vivenda* v = dynamic_cast<Vivenda*> (habitacoes[ind]);
        switch (param) {
            case 1:
                std::cout << "\nIntroduza o novo ID:", getline(std::cin, aux);
                verifyId(stoi(aux));
                (*v).setId(aux);
                break;
            case 2:
                std::cout << "\nIntroduza a nova Morada:", getline(std::cin, aux);
                (*v).setMorada(aux);
                break;
            case 3:
                std::cout << "\nIntroduza o novo Valor Base:", getline(std::cin, aux);
                (*v).setValorBase(aux);
                break;
            case 4:
                std::cout << "\nIntroduza a nova Area Habitacional:", getline(std::cin, aux);
                (*v).setAreaHabitacional(aux);
                break;
            case 5:
                std::cout << "\nIntroduza a nova Area Exterior:", getline(std::cin, aux);
                (*v).setAreaExterior(aux);
                break;
            case 6:
                std::cout << "\nIntroduza tem Piscina?('sim'\\'nao'):", getline(std::cin, aux);
                (*v).setPiscina(aux);
                break;
            case 7:
                std::cout << "\nIntroduza esta Pago?('sim'\\'nao'):", getline(std::cin, aux);
                (*v).setPago(aux);
                break;
            case 8:
                std::cout << "\nIntroduza esta Disponivel('sim'\\'nao'):", getline(std::cin, aux);
                (*v).setDisponibilidade(aux);
                break;
        }
    }
    else {
        Apartamento* a = dynamic_cast<Apartamento*> (habitacoes[ind]);
        switch (param) {
            case 1:
                std::cout << "\nIntroduza o novo ID:", getline(std::cin, aux);
                verifyId(stoi(aux));
                (*a).setId(aux);
                break;
            case 2:
                std::cout << "\nIntroduza a nova Morada:", getline(std::cin, aux);
                (*a).setMorada(aux);
                break;
            case 3:
                std::cout << "\nIntroduza o novo Valor Base:", getline(std::cin, aux);
                (*a).setValorBase(aux);
                break;
            case 4:
                std::cout << "\nIntroduza a nova Area Habitacional:", getline(std::cin, aux);
                (*a).setAreaHabitacional(aux);
                break;
            case 5:
                std::cout << "\nIntroduza o novo Piso:", getline(std::cin, aux);
                (*a).setPiso(aux);
                break;
            case 6:
                std::cout << "\nIntroduza a nova Tipologia:", getline(std::cin, aux);
                (*a).setTipologia(aux);
                break;
            case 7:
                std::cout << "\nIntroduza esta Pago?('sim'\\'nao'):", getline(std::cin, aux);
                (*a).setPago(aux);
                break;
            case 8:
                std::cout << "\nIntroduza esta Disponivel('sim'\\'nao'):", getline(std::cin, aux);
                (*a).setDisponibilidade(aux);
                break;
        }
    }
    cout << "\nHabitacao alterada com sucesso!\n\n";
    habitacoes[ind]->imprime();
}

void Condominio::removerHabitacao(){
    verTodosHabitacoes(0);
    string aux, aux1 = "";
    int onde = -1;
    cin.ignore(1000, '\n');
    cout << "Introduza o ID do pacote:", getline(cin, aux);
    for (int i = 0; i < aux.length(); i++) {
        if (!isdigit(aux[i]) && aux[i] != ' ')
            throw invalid_argument("Erro no atributo ID!");
        else if(aux[i] != ' ')
            aux1 += string(1, aux[i]);
    }
    for(int i = 0; i < habitacoes.size(); i++){
        if(habitacoes[i]->getId() == stoi(aux1)){
            onde = i;
            break;
        }
    }
    if(onde == -1)
        throw runtime_error("Nao existe nenhum pacote com o ID: " + aux);
    habitacoes.erase(habitacoes.begin() + onde);
    cout << "\nHabitacao removida com sucesso!";
}

void Condominio::verifyId(int id){
    for(int i = 0; i < habitacoes.size(); i++){
        if(habitacoes[i]->getId() == id)
            throw runtime_error("Ja existe um pacote com o id: " + id);
    }
}

void Condominio::verifyNif(string &nif){
    string aux = "";
    for (int i = 0; i < nif.length(); i++) {
        if (!isdigit(nif[i]) && nif[i] != ' ')
            throw invalid_argument("Erro ao no atributo Nif!");
        else if(nif[i] != ' ')
            aux += string(1, nif[i]);
    }
    if(aux.length() != 9)
        throw invalid_argument("O atributo nif tem de ter 9 numeros!");
    for(int i = 0; i < clientes.size(); i++){
        if(clientes[i].getNif() == stoi(aux))
            throw runtime_error("Ja existe um cliente com esse NIF: " + nif);
    }
    nif = aux;
}

void Condominio::pagar(){
    imprimeTodosClientes(0);
    string aux;
    cin.ignore(1000, '\n');
    cout << "Introduza o nome do Cliente:", getline(cin, aux);
    formataNome(aux);
    Cliente c(aux);
    vector<Cliente>::iterator it = find(clientes.begin(), clientes.end(), c);
    if(it == clientes.end())
        throw runtime_error("Nao existe nenhum cliente com o nome: "  + aux);
    int id = it->pagarMen();
    for(int i = 0; i < habitacoes.size(); i++){
        if(habitacoes[i]->getId() == id){
            habitacoes[i]->setPago("sim");
            break;
        }
    }
    cout << "\nMensalidade paga com sucesso!";
}

void Condominio::imprimeApartamentos(){
    for (int i = 0; i < habitacoes.size(); i++){
       if(habitacoes[i]->getTipo() == "Apartamento")
           habitacoes[i]->imprime();
    }
}

void Condominio::imprimeVivendas(){
    for (int i = 0; i < habitacoes.size(); i++){
        if(habitacoes[i]->getTipo() == "Vivenda")
            habitacoes[i]->imprime();
    }
}

void Condominio::verLucMen() {
    double lucro = 0;
    for(int i = 0; i < habitacoes.size(); i++){
        if(habitacoes[i]->getPago() == true)
            lucro += habitacoes[i]->getMensalidade();
    }
    cout << "O Condominio lucrou com base nas Mensalidades em: " << lucro << " $!\n\n";
}

void Condominio::addServico(Servicos &c,int indice){
    if (indice==-1){
        for(int i=0; i<servicos.size();i++){
            if (servicos.at(i).getservico()==c.getservico()){
                if (servicos.at(i).getprestador()==c.getprestador())
                    throw runtime_error("Já existe um prestador com o mesmo nome que presta o mesmo servico!");
            }
        }
        servicos.push_back(c);
        cout << "\nServico adicionado com sucesso!\n\n";
        servicos.at(servicos.size()-1).imprime();
    }
    else{
        for(int i=0; i<servicos.size();i++){
            if (servicos.at(i).getservico()==c.getservico()){
                if (servicos.at(i).getprestador()==c.getprestador())
                    throw runtime_error("Já existe um prestador com o mesmo nome que presta o mesmo servico!");
            }
        }
        servicos.push_back(c);
        servicos.erase(servicos.begin()+indice);
        cout << "\nServico de Limpeza reposto com sucesso!\n\n";
        servicos.at(servicos.size()-1).imprime();
    }
}

void Condominio::alterarServico(){
    int op;
    float preco;
    string aux;
    for(int i=0;i<servicos.size();i++){
        cout<<i+1<<". "<<servicos.at(i).getservico()<<" - "<<servicos.at(i).getprestador()<<"\n";
    }
    cout<<"\nIntroduza o numero do servico que pretende alterar:";cin>>op;
    while (cin.fail()||(op<1)||(op>servicos.size())){
        if (std::cin.fail()) {
            std::cin.clear();
            std::cin.ignore(1000, '\n');
        } else {
            std::cin.ignore(1000, '\n');
        }
        cout << "Opcao Invalida! Introduza novamente:", cin >> op;
    }
    cout << "\n\t\tPARAMETRO A ALTERAR\n\n"
         << "1) Tipo de Servico;\n2) Prestador;\n3) Preco Mensal;";
    int param = Opcao(false, 3);
    cin.ignore(1000, '\n');
    switch (param){
        case  1:
            cout<<"\nIntroduza o tipo de servico:";getline(cin,aux);
            if(aux=="Limpeza")
                throw runtime_error("Nao e possivel alterar o tipo de servico para Limpeza!");
            servicos.at(op-1).setservico(aux);
            break;
        case 2:
            cout<<"\nIntroduza o prestador:";getline(cin,aux);
            servicos.at(op-1).setprestador(aux);
            break;
        case 3:
            cout<<"\nIntroduza o preco mensal:";cin>>preco;
            while (cin.fail()||preco<0){
                if (std::cin.fail()) {
                    std::cin.clear();
                    std::cin.ignore(1000, '\n');
                } else {
                    std::cin.ignore(1000, '\n');
                }
                cout << "Preco invalido, introduza novamente:", cin >> preco;
            }
            servicos.at(op-1).setprecomensal(preco);
            break;
    }
    cout << "\nServico alterado com sucesso!\n\n";
    servicos.at(op-1).imprime();
}

void Condominio::removerServico(int &indice){
    int op;
    for(int i=0;i<servicos.size();i++){
        cout<<i+1<<". "<<servicos.at(i).getservico()<<" - "<<servicos.at(i).getprestador()<<"\n";
    }
    cout<<"\nIntroduza o numero do servico que pretende remover:";cin>>op;
    while (cin.fail()||(op<1)||(op>servicos.size())){
        if (std::cin.fail()) {
            std::cin.clear();
            std::cin.ignore(1000, '\n');
        } else {
            std::cin.ignore(1000, '\n');
        }
        cout << "Opcao Invalida! Introduza novamente:", cin >> op;
    }
    if (servicos.at(op-1).getservico()=="Limpeza"){
        indice=op-1;
        throw runtime_error("Nao e possivel remover um servico do tipo Limpeza!");
    }
    servicos.erase(servicos.begin()+(op-1));
    cout << "\nServico removido com sucesso!\n\n";
}

void Condominio::verifyServico(string &servico,float &preco,const string &prestador,bool limpeza) {
    cin>>preco;
    if (cin.fail()){
        cin.clear();
        cin.ignore(1000,'\n');
        throw invalid_argument("Erro no Preco Mensal, este deve apenas conter numeros e caso for necessario um \".\"(ponto) a sinalizar a virgula!");
    }
    else if (preco<0){
        throw invalid_argument("Erro no Preco Mensal, o preco nao pode ser negativo!");
    }
    if (limpeza){
        while (servico!="Limpeza"){
            cout<<"\nErro no Tipo de Servico, e necessario que seja introduzido \"Limpeza\"!"<<endl
                <<"\nIntroduza novamente o tipo de servico:";
            getline(cin,servico);
        }
    }
    else{
        string tmp="";
        if (servico.empty())
            throw invalid_argument("Erro no Tipo de Servico, e necessario identificar o tipo de servico!");
        for (int i=0;i<servico.length();i++){
            if (servico[i]==' ')
                continue;
            else if (!isalpha(servico[i]))
                throw invalid_argument("Erro no Tipo de Sevico!");
            else
                tmp+=toupper(servico[i]);
        }
        if (tmp=="LIMPEZA")
            throw runtime_error("Nao e possivel criar um servico do tipo Limpeza, pois esta estabelecido um limite de prestadores para este servico!");
    }
    if (prestador.empty())
        throw logic_error("Erro no Prestador, e necessario identificar o prestador do servico!");
}

void Condominio::iniciarServico() {
    int op, cont=0;
    vector<Servicos*> servicos_disponiveis;
    bool presente= true;
    cout << "\n\nXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n\t\tINICIAR SERVICO\n\n";
    for (int i=0; i<servicos.size();i++){
        if (servicos.at(i).getdisponibilidade())
            servicos_disponiveis.push_back(&servicos.at(i));
    }
    if (servicos_disponiveis.empty())
        cout<<"Nao existem servicos disponiveis no momento.\n\n";
    else{
        for (int i = 0; i <servicos_disponiveis.size() ; ++i) {
            for (int j=i+1;j<servicos_disponiveis.size();j++){
                if (servicos_disponiveis.at(i)->getservico()==servicos_disponiveis.at(j)->getservico()){
                    if (servicos_disponiveis.at(i)->getnumocorrencias()<servicos_disponiveis.at(j)->getnumocorrencias()){
                        servicos_disponiveis.erase(servicos_disponiveis.begin()+j);
                    }
                    else{
                        servicos_disponiveis.erase(servicos_disponiveis.begin()+i);
                    }
                }
            }
        }
        for (int k=0;k<servicos_disponiveis.size();k++){
            cout<<k+1<<". "<<servicos_disponiveis.at(k)->getservico()<<"\n";
            cont++;
        }
        cout<<"0. Voltar"<<endl;
        op=Opcao(true,cont);
        if (op==0)
            return;
        cout << "\n\nXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n\t\tINICIAR SERVICO\n\n";
        if (habitacoes.empty())
            cout<<"Nao exite nenhuma habitacao registada neste condominio!\n\n";
        else{
            cin.ignore(1000,'\n');
            string aux,aux1="";
            cout << "Introduza o ID do pacote da Habitacao na qual pretende realizar o servico: ", getline(cin, aux);
            for (int i = 0; i < aux.length(); i++) {
                if (!isdigit(aux[i]) && aux[i] != ' ')
                    throw invalid_argument("Erro no atributo ID!");
                else if(aux[i] != ' ')
                    aux1 += string(1, aux[i]);
            }
            int ind=-1;
            for(int i = 0; i < habitacoes.size(); i++){
                if(habitacoes[i]->getId() == stoi(aux1)){
                    ind = i;
                    break;
                }
            }
            if(ind == -1)
                throw invalid_argument("Nao existe nenhuma  habitacao com o ID: "+aux+"\n\n");
            else{
                servicos_disponiveis.at(op-1)->startservico(habitacoes.at(ind)->getId(),habitacoes.at(ind)->getProprietario());
                cout<<"\nO servico "<<servicos_disponiveis.at(op-1)->getservico()<<" foi iniciado com sucesso!"<<endl<<endl;
            }
        }
    }
    system("pause");
}

void Condominio::cancelServico() {
    int op;
    cout << "\n\nXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n\t\tCANCELAR SERVICO\n\n";
    vector<Servicos*> servicos_a_decorrer;
    for(int i=0;i<servicos.size();i++){
        if (!servicos.at(i).getdisponibilidade()){
            servicos_a_decorrer.push_back(&servicos.at(i));
        }
    }
    if (servicos_a_decorrer.empty()){
        cout<<"Nao esta a decorrer nenhum servico no momento!"<<endl<<endl;
    }
    else{
        cout<<"  Servico     ID(Habitacao)                       Data(Inicio)                  Data(Fim)              Estado"<<endl<<endl;
        for(int j=0;j<servicos_a_decorrer.size();j++){
            cout<<j+1<<".";
            servicos_a_decorrer.at(j)->printhistoricobyestado("A Decorrer...");
        }
        cout<<"0.Voltar";
        op=Opcao(true,servicos_a_decorrer.size());
        if (op==0)
            return;
        servicos_a_decorrer.at(op-1)->cancelservico();
        cout<<"\nServico cancelado com sucesso!\n\n";
    }
    system("pause");
}

void Condominio::terminarServico() {
    int op;
    cout << "\n\nXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n\t\tTERMINAR SERVICO\n\n";
    vector<Servicos*> servicos_a_decorrer;
    for(int i=0;i<servicos.size();i++){
        if (!servicos.at(i).getdisponibilidade()){
            servicos_a_decorrer.push_back(&servicos.at(i));
        }
    }
    if (servicos_a_decorrer.empty()){
        cout<<"Nao esta a decorrer nenhum servico no momento!"<<endl<<endl;
    }
    else{
        cout<<"  Servico     ID(Habitacao)                       Data(Inicio)                  Data(Fim)              Estado"<<endl<<endl;
        for(int j=0;j<servicos_a_decorrer.size();j++){
            cout<<j+1<<".";
            servicos_a_decorrer.at(j)->printhistoricobyestado("A Decorrer...");
        }
        cout<<"0.Voltar";
        op=Opcao(true,servicos_a_decorrer.size());
        if (op==0)
            return;
        servicos_a_decorrer.at(op-1)->finishservico();
        cout<<"\nServico terminado com sucesso!\n\n";
    }
    system("pause");
}

/**
 * ordena os servicos por ordem alfabetica
 * @param i servico utilizado para a comparacao
 * @param j servico utilizado para a comparacao
 * @return retorna true se o servico i for primeiro por ordem alfabetica e false caso contrario
 */
bool compServ(Servicos i,Servicos j){ return i.getservico()<j.getservico();}

void Condominio::imprimeTodosServicos() {
    vector<Servicos> temp=servicos;
    sort(temp.begin(),temp.end(),compServ);
    for(int i=0;i<temp.size();i++){
        temp.at(i).imprime();
    }
}

void Condominio::imprimeServicosPorEstado(int op) {

    switch(op){
        case 1:{
            cout<<"\n\nXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n\t\tSERVICOS A DECORRER\n\n";
            int tmp=0;
            for (int j=0;j<servicos.size();j++){
                if (!servicos.at(j).getdisponibilidade())
                    tmp++;
            }
            if (tmp==0){
                cout<<"\nNao existe nenhum servico a decorrer no momento."<<endl;
                return;
            }
            cout<<"Servico       ID(Habitacao)                    Data(Inicio)                  Data(Fim)              Estado"<<endl<<endl;
            for (int i = 0;i<servicos.size() ; i++) {
                servicos.at(i).printhistoricobyestado("A Decorrer...");
            }
            break;
        }
        case 2:{
            cout<<"\n\nXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n\t\tSERVICOS CANCELADOS\n\n";
            int tmp=0;
            for (int j=0;j<servicos.size();j++){
                if((!servicos.at(j).historico_empty())&&(servicos.at(j).getdisponibilidade())&&(servicos.at(j).getnumocorrencias()==0))
                    tmp++;
            }
            if (tmp==0){
                cout<<"\nNao existe nenhum servico cancelado no momento."<<endl;
                return;
            }
            cout<<"Servico       ID(Habitacao)                    Data(Inicio)                  Data(Fim)              Estado"<<endl<<endl;
            for (int i = 0;i<servicos.size() ; i++) {
                servicos.at(i).printhistoricobyestado("Cancelado");
            }
            break;
        }

        case 3: {
            cout<<"\n\nXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n\t\tSERVICOS TERMINADOS\n\n";
            int tmp = 0;
            for (int j = 0; j < servicos.size(); j++) {
                if ((!servicos.at(j).historico_empty())&&(servicos.at(j).getdisponibilidade()))
                    tmp++;
            }
            if (tmp == 0) {
                cout << "\nNao existe nenhum servico terminado no momento." << endl;
                return;
            }
            cout<< "Servico       ID(Habitacao)                    Data(Inicio)                  Data(Fim)              Estado"<< endl << endl;
            for (int i = 0; i < servicos.size(); i++) {
                servicos.at(i).printhistoricobyestado("Terminado");
            }
            break;
        }
    }
}

void Condominio::imprimeServicosHabitacao() {
    cin.ignore(1000,'\n');
    string aux,aux1="";
    cout << "Introduza o ID do pacote da Habitacao na qual pretende realizar o servico:", getline(cin, aux);
    for (int i = 0; i < aux.length(); i++) {
        if (!isdigit(aux[i]) && aux[i] != ' ')
            throw invalid_argument("Erro no atributo ID!");
        else if(aux[i] != ' ')
            aux1 += string(1, aux[i]);
    }
    int ind=-1;
    for(int i = 0; i < habitacoes.size(); i++){
        if(habitacoes[i]->getId() == stoi(aux1)){
            ind = i;
            break;
        }
    }
    if(ind == -1){
        throw invalid_argument("\nNao existe nenhuma  habitacao com o ID: "+aux+"\n\n");
    }
    cout<<"\n\nXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n\t\tVER TODOS SERVICOS PRESTADOS NUMA HABITACAO\n\n";
    cout<< "Servico       ID(Habitacao)                    Data(Inicio)                  Data(Fim)              Estado"<< endl << endl;
    for(int i=0;i<servicos.size();i++){
        servicos.at(i).printhistoricobylocal(habitacoes.at(ind)->getId());
    }
}

void Condominio::imprimeServicosCliente() {
    imprimeTodosClientes(0);
    string aux;
    cin.ignore(1000, '\n');
    cout << "Introduza o nome do cliente:", getline(cin, aux);
    formataNome(aux);
    int ind=-1;
    for(int i = 0; i < clientes.size(); i++){
        if(clientes[i].getNome() == aux){
            ind = i;
            break;
        }
    }
    if (ind==-1){
        throw invalid_argument("\nNao existe nenhum cliente com o nome: "+aux+"\n\n");
    }
    cout<<"\n\nXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n\t\tVER TODOS SERVICOS PRESTADOS A UM CLIENTE\n\n";
    cout<< "Servico       ID(Habitacao)                    Data(Inicio)                  Data(Fim)              Estado"<< endl << endl;
    for(int i=0;i<servicos.size();i++){
        servicos.at(i).printhistoricobycliente(habitacoes.at(ind)->getProprietario());
    }
}

/**
 * compara as datas dos dois servicos realizados e colocas por ordem cronologica
 * @param i tempo utilizado para comparacao
 * @param j tempo utilizado para comparacao
 * @return retorna true se o i tiver sido antes do que j
 */
bool compHistorico(Info_Servico i,Info_Servico j){
    if (i.tempo_incial.tm_year<j.tempo_incial.tm_year)
        return true;
    else if (i.tempo_incial.tm_year>j.tempo_incial.tm_year)
        return false;
    else if (i.tempo_incial.tm_mon< j.tempo_incial.tm_mon)
        return true;
    else if (i.tempo_incial.tm_mon >j.tempo_incial.tm_mon)
        return false;
    else if (i.tempo_incial.tm_mday < j.tempo_incial.tm_mday)
        return true;
    else if (i.tempo_incial.tm_mday > j.tempo_incial.tm_mday)
        return false;
    else if (i.tempo_incial.tm_hour < j.tempo_incial.tm_hour)
        return true;
    else if (i.tempo_incial.tm_hour > j.tempo_incial.tm_hour)
        return false;
    else if (i.tempo_incial.tm_min < j.tempo_incial.tm_min)
        return true;
    else if (i.tempo_incial.tm_min > j.tempo_incial.tm_min)
        return false;
    else if (i.tempo_incial.tm_sec < j.tempo_incial.tm_sec)
        return true;
    else if (i.tempo_incial.tm_sec > j.tempo_incial.tm_sec)
        return false;
    return true;
}

void Condominio::imprimeServicosOrdemCrono() {
    vector<Info_Servico> historico;
    vector<Info_Servico> tmp;
    for (int i=0;i<servicos.size();i++){
        tmp=servicos.at(i).getHistorico();
        for (int j=0;j<tmp.size();j++){
            historico.push_back(tmp.at(j));
        }
    }
    sort(historico.begin(),historico.end(),compHistorico);
    cout<< "Servico       ID(Habitacao)                    Data(Inicio)                  Data(Fim)              Estado"<< endl << endl;
    for (int i = 0; i <historico.size() ; i++) {
        if (historico.at(i).estado=="A Decorrer...")
            cout<<left<<setw(20)<<historico.at(i).servico<<
                right<<setw(5)<<historico.at(i).id<<
                right<<setw(20)<<historico.at(i).tempo_incial.tm_hour<<":"<<historico.at(i).tempo_incial.tm_min<<":"<<historico.at(i).tempo_incial.tm_sec<<" "<<historico.at(i).tempo_incial.tm_mday<<"/"<<historico.at(i).tempo_incial.tm_mon<<"/"<<historico.at(i).tempo_incial.tm_year<<
                right<<setw(27)<<"--:--:-- --/--/----"<<
                right<<setw(20)<<historico.at(i).estado<<endl;
        else
            cout<<left<<setw(20)<<historico.at(i).servico<<
                right<<setw(5)<<historico.at(i).id<<
                right<<setw(20)<<historico.at(i).tempo_incial.tm_hour<<":"<<historico.at(i).tempo_incial.tm_min<<":"<<historico.at(i).tempo_incial.tm_sec<<" "<<historico.at(i).tempo_incial.tm_mday<<"/"<<historico.at(i).tempo_incial.tm_mon<<"/"<<historico.at(i).tempo_incial.tm_year<<
                right<<setw(10)<<historico.at(i).tempo_final.tm_hour<<":"<<historico.at(i).tempo_final.tm_min<<":"<<historico.at(i).tempo_final.tm_sec<<" "<<historico.at(i).tempo_final.tm_mday<<"/"<<historico.at(i).tempo_final.tm_mon<<"/"<<historico.at(i).tempo_final.tm_year<<
                right<<setw(20)<<historico.at(i).estado<<endl;
    }
}

void Condominio::verDesp(){
    float soma = 0;
    for(int i = 0; i < servicos.size(); i++)
        soma += servicos[i].getprecomensal();
    cout << "O Condominio teve uma despesa com os servicos de: " << soma << " $!\n\n";
}

//---------------------------------------------------------
//                  AUXILIARES
//---------------------------------------------------------

int Opcao(bool zero, int num){
    int op;
    if(zero == true) {
        std::cout << "\n\nInsira a sua opcao: ", std::cin >> op;
        while (std::cin.fail() || op < 0 || op > num) {
            if (std::cin.fail()) {
                std::cin.clear();
                std::cin.ignore(1000, '\n');
            } else {
                std::cin.ignore(1000, '\n');
            }
            std::cout << "Opcao Invalida! Insira a sua opcao: ", std::cin >> op;
        }
    }
    else{
        std::cout << "\n\nInsira a sua opcao: ", std::cin >> op;
        while (std::cin.fail() || op < 1 || op > num) {
            if (std::cin.fail()) {
                std::cin.clear();
                std::cin.ignore(1000, '\n');
            } else {
                std::cin.ignore(1000, '\n');
            }
            std::cout << "Opcao Invalida! Insira a sua opcao: ", std::cin >> op;
        }
    }
    return op;
}



