#include "Condominio.h"
#include <fstream>

/**
 * funcao usada na ordenacao de habitacoes com base no ID
 * @param h1 apontador para uma habitacao
 * @param h2 apontador para uma habitacao
 * @return retorna se um id e menor que outro
 */
bool compId(Habitacao *h1, Habitacao *h2){
    return h1->getId() < h2->getId();
}

/**
 * funcao usada na ordenacao de habitacoes com base na area habitacional
 * @param h1 apontador para uma habitacao
 * @param h2 apontador para uma habitacao
 * @return retorna se uam area e menor que outra
 */
bool compAA(Habitacao *h1, Habitacao *h2){
    return h1->getAreaHabitacional() < h2->getAreaHabitacional();
}

void Condominio::readFile(){
    //---------------------------
    string aux;
    ifstream entrada;
    cout << "Nome do Ficheiro: ", std::cin >> aux;
    entrada.open(aux);
    //verifica se houve algum erro ao tentar abrir o ficheiro
    while(std::cin.fail() || !entrada.is_open()){
        if(std::cin.fail()) {
            std::cin.clear();
            std::cin.ignore(1000, '\n');
        }
        else
            std::cin.ignore(1000, '\n');
        std::cout << "Erro! Nome do Ficheiro: ", std::cin >> aux;
        entrada.open(aux);
    }
    nomeFicheiro = aux;
    //----------------------------
    //Le o ficheiro do condominio
    getline(entrada, aux);  //le palavra Habitacoes
    getline(entrada, aux); // le palavra seguinte a habitacoes
    while(aux != "CLIENTES") { // se a palvra nao for servicos
        if(aux == "Vivenda"){
            Vivenda *v = new Vivenda();
            (*v).setTipo(aux);
            getline(entrada, aux), (*v).setId(aux);
            getline(entrada, aux), (*v).setMorada(aux);
            getline(entrada, aux), (*v).setValorBase(aux);
            getline(entrada, aux), (*v).setAreaHabitacional(aux);
            getline(entrada, aux), (*v).setAreaExterior(aux);
            getline(entrada, aux), (*v).setPiscina(aux);
            getline(entrada, aux), (*v).setDisponibilidade(aux);
            v->setPago("nao"), v->calcImposto();
            habitacoes.push_back(v);
        }
        else{
            Apartamento *a = new Apartamento();
            (*a).setTipo(aux);
            getline(entrada, aux), (*a).setId(aux);
            getline(entrada, aux), (*a).setMorada(aux);
            getline(entrada, aux), (*a).setValorBase(aux);
            getline(entrada, aux), (*a).setAreaHabitacional(aux);
            getline(entrada, aux), (*a).setPiso(aux);
            getline(entrada, aux), (*a).setTipologia(aux);
            getline(entrada, aux), (*a).setDisponibilidade(aux);
            (*a).setPago("nao"), a->calcImposto();
            habitacoes.push_back(a);
        }
        getline(entrada, aux);
    }
    getline(entrada, aux); // le palavra seguinte a clientes
    while(aux != "SERVICOS") {
        Cliente *cl = new Cliente();
        cl->setNome(aux);
        getline(entrada, aux), cl->setNif(aux);
        getline(entrada, aux), cl->setIds(aux);
        clientes.push_back(*cl);
        getline(entrada, aux);
    }
    getline(entrada, aux); //le palavra servicos
    update = false;
    entrada.close();
    //-------------------------

}

void Condominio::writeFile(){
    char res;
    if(update == true){//o ficheiro foi alterado
        std::cout << "\nXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n";
        std::cout << "Pretende guardar as alteracoes efetuadas('s'\\'n'): ", std::cin >> res;
        while(std::cin.fail() || (res!= 's' && res!='n')){
            if(std::cin.fail()){
                std::cin.clear();
                std::cin.ignore(1000, '\n');
            }
            std::cout << "Erro! Pretende guardar as alteracoes efetuadas('s'\\'n'): ", std::cin >> res;
        }
        if(res == 's'){
            std::ofstream saida1;
            saida1.open(nomeFicheiro);
            saida1 << "HABITACOES";
            for(int i = 0; i < habitacoes.size(); i++){
                if(habitacoes[i]->getTipo() == "Vivenda") {
                    Vivenda *v = dynamic_cast<Vivenda *> (habitacoes[i]);
                    saida1 << endl << v->getTipo()
                           << std::endl << v->getId()
                           << std::endl << v->getMorada()
                           << std::endl << v->getValorBase()
                           << std::endl << v->getAreaHabitacional()
                           << std::endl << v -> getAreaExterior();
                    if(v -> getPiscina() == true)
                        saida1 << "\nsim";
                    else
                        saida1 << "\nnao";
                    if(v -> getDisponivel() == true)
                        saida1 << "\nsim";
                    else
                        saida1 << "\nnao";
                }
                else{
                    Apartamento *a = dynamic_cast<Apartamento *> (habitacoes[i]);
                    saida1 << endl << a->getTipo()
                           << std::endl << a->getId()
                           << std::endl << a->getMorada()
                           << std::endl << a->getValorBase()
                           << std::endl << a->getAreaHabitacional()
                           << std::endl << a -> getPiso()
                           << std::endl << a -> getTipologia();
                    if(a -> getDisponivel() == true)
                        saida1 << "\nsim";
                    else
                        saida1 << "\nnao";
                }
            }
            saida1 << std::endl << "CLIENTES";
            for(int i = 0; i < clientes.size(); i++){
                saida1 << endl << clientes[i].getNome()
                       << std::endl << clientes[i].getNif();
                if(clientes[i].getIds().size() == 0)
                    saida1 << "\n-";
                else{
                    vector<int> ids = clientes[i].getIds();
                    saida1 << endl;
                    for(int j = 0; j < ids.size(); j++){
                        if(j == ids.size() - 1)
                            saida1 << ids[j];
                        else
                            saida1 << ids[j] << "; ";
                    }
                }

            }
            saida1 << "\nSERVICOS";
            saida1.close();
            std::cout << "\nAs alteracoes foram gravadas com sucesso!\n\n";
            exit(1);
        }
        else
            exit(1);
    }
    else
        exit(1);
}

void Condominio::imprimeTodosClientes(int op) const{
    vector<Cliente> a = clientes;
    if(op == 1)
      sort(a.begin(), a.end());
    for(int i = 0; i < a.size(); i++) {
        a[i].imprime();
        cout << endl << endl;
    }
}

void Condominio::imprimeCliente() const{
    string aux;
    cin.ignore(1000, '\n');
    cout << "Introduza o nome do Cliente: ", getline(cin, aux);
    formataNome(aux);
    int ind = -1;
    for(int i = 0; i < clientes.size(); i++){
        if(clientes[i].getNome() == aux)
            ind = i;
    }
    if(ind == -1)
        throw logic_error("Nao existe nenhum cliente com o nome: "  + aux);
    else
        clientes[ind].imprime();
}

void Condominio::verTodosHabitacoes(int op) const{
    vector<Habitacao*> h = habitacoes;
    if(op == 1)
        sort(h.begin(), h.end(), compId);
    else if(op == 2)
        sort(h.begin(), h.end(), compAA);
    for (int i = 0; i < h.size(); i++)
        h[i]->imprime();
}

void Condominio::verHabitacaoEsp()const{
    string aux, aux1 = "";
    cin.ignore(1000, '\n');
    cout << "Introduza o ID do pacote: ", getline(cin, aux);
    for (int i = 0; i < aux.length(); i++) {
        if (!isdigit(aux[i]) && aux[i] != ' ')
            throw logic_error("Erro no atributo ID!");
        else if(aux[i] != ' ')
            aux1 += string(1, aux[i]);
    }
    int ind=-1;
    for(int i = 0; i < habitacoes.size(); i++){
        if(habitacoes[i]->getId() == stoi(aux1)){
            ind = i;
            break;
        }
    }
    if(ind == -1)
        throw logic_error("Nao existe nenhuma  habitacao com o ID: "  + aux);
    else{
        cout << endl;
        habitacoes[ind]->imprime();
    }
}

void Condominio::addCliente(Cliente &c){
    clientes.push_back(c);
    cout << "\nCliente adicionado com sucesso!\n\n";
    clientes[clientes.size() - 1].imprime();
}

void Condominio::alterarCliente(){
    imprimeTodosClientes(0);
    string aux;
    cin.ignore(1000, '\n');
    cout << "Introduza o nome do cliente: ", getline(cin, aux);
    formataNome(aux);
    int ind=-1;
    for(int i = 0; i < clientes.size(); i++){
        if(clientes[i].getNome() == aux){
            ind = i;
            break;
        }
    }
    if(ind == -1)
        throw logic_error("Nao existe nenhum cliente com o nome: "  + aux);
    std::cout << "\n\t\tPARAMETRO A ALTERAR\n\n"
              << "1) Nome;\n2) Nif;\n3) Ids;";
    int param = Opcao(false, 3);
    cin.ignore(1000, '\n');
    switch (param) {
        case 1:
            std::cout << "\nIntroduza o novo nome: ", getline(std::cin, aux);
            clientes[ind].setNome(aux);
            break;
        case 2:
            std::cout << "\nIntroduza o novo NIF: ", getline(std::cin, aux);
            verifyNif(aux);
            clientes[ind].setNif(aux);
            break;
        case 3:
            std::cout << "\nIntroduza os novos IDS('-' para nenhum): ", getline(std::cin, aux);
            vector<int> ids = splitIds(aux);
            bool existe;
            for(int i = 0; i < ids.size(); i++){
                existe = false;
                for(int j = 0; j < habitacoes.size(); j++){
                    if(ids[i] == habitacoes[j]->getId()) {
                        existe = true;
                        break;
                    }
                }
                if(existe == false)
                    throw ids[i];
            }
            clientes[ind].setIds(aux);
            break;
    }
    cout << "\nHabitacao alterada com sucesso!\n\n";
    clientes[ind].imprime();
}

void Condominio::removerCliente(){
    imprimeTodosClientes(0);
    string aux;
    cin.ignore(1000, '\n');
    cout << "Introduza o nome do Cliente: ", getline(cin, aux);
    formataNome(aux);
    Cliente c(aux);
    vector<Cliente>::iterator it = find(clientes.begin(), clientes.end(), c);
    if(it == clientes.end())
        throw logic_error("Nao existe nenhum cliente com o nome: "  + aux);
    clientes.erase(it);
    cout << "\nCliente removido com sucesso!";
}

void Condominio::associarHabit(){
    imprimeTodosClientes(0);
    string aux;
    cin.ignore(1000, '\n');
    cout << "Introduza o nome do Cliente: ", getline(cin, aux);
    formataNome(aux);
    Cliente c(aux);
    vector<Cliente>::iterator it = find(clientes.begin(), clientes.end(), c);
    if(it == clientes.end())
        throw logic_error("Nao existe nenhum cliente com o nome: "  + aux);
    vector<int> disp;
    cout << endl;
    for(int i = 0; i < habitacoes.size(); i++){
        if(habitacoes[i]->getDisponivel() == true) {
            disp.push_back(habitacoes[i]->getId());
            habitacoes[i]->imprime();
        }
    }
    string id;
    cout << "Introduza o ID do pacote que pretende associar: ", getline(cin, id);
    sort(disp.begin(), disp.end());
    bool existe = binary_search(disp.begin(), disp.end(), stoi(id));
    if(existe == false)
        throw logic_error("Nao existe atualmente nenhuma habitacao disponivel com o ID " + id + " para adquirir!");
    it->assocHabit(stoi(id));
    for(int i = 0; i < habitacoes.size(); i++){
        if(habitacoes[i]->getId() == stoi(id)){
            habitacoes[i]->setDisponibilidade("nao");
        }
    }
    cout << "Habitacao adquirida com sucesso!\n\n";
    it->imprime();
}

void Condominio::desassociarHabit(){
    imprimeTodosClientes(0);
    string aux;
    cin.ignore(1000, '\n');
    cout << "Introduza o nome do Cliente: ", getline(cin, aux);
    formataNome(aux);
    Cliente c(aux);
    vector<Cliente>::iterator it = find(clientes.begin(), clientes.end(), c);
    if(it == clientes.end())
        throw logic_error("Nao existe nenhum cliente com o nome: "  + aux);
    vector<int> ids = it->getIds();
    cout << endl;
    for(int i = 0; i < habitacoes.size(); i++){
        if(it->existe(habitacoes[i]->getId()))
            habitacoes[i]->imprime();
    }
    string id;
    cout << "Introduza o ID da Habitacao: ", getline(cin, id);
    bool existe = it->existe(stoi(id));
    if(existe == false)
        throw logic_error("Nao existe nenhum pacote com o ID " + id + " para desassociar!");
    it->desassociarHabit(stoi(id));
    for(int i = 0; i < habitacoes.size(); i++){
        if(habitacoes[i]->getId() == stoi(id)) {
            habitacoes[i]->setDisponibilidade("sim");
            break;
        }
    }
    cout << "\nHabitacao desassociada com sucesso!\n\n";
    it->imprime();
}

void Condominio::addHabitacao(Habitacao *h){
    for(int i = 0; i < habitacoes.size(); i++){
        if(habitacoes[i]->getId() == h->getId())
            throw logic_error("Ja existe um pacote com o ID: " + h->getId());
    }
    habitacoes.push_back(h);
    cout << "\nHabitacao adicionada com sucesso!\n\n";
    habitacoes[habitacoes.size() - 1]->imprime();
}

void Condominio::alterarHabitacao(){
    verTodosHabitacoes(0);
    string aux, aux1 = "";
    cin.ignore(1000, '\n');
    cout << "Introduza o ID do pacote: ", getline(cin, aux);
    for (int i = 0; i < aux.length(); i++) {
        if (!isdigit(aux[i]) && aux[i] != ' ')
            throw logic_error("Erro no atributo ID!");
        else if(aux[i] != ' ')
            aux1 += string(1, aux[i]);
    }
    int ind=-1;
    for(int i = 0; i < habitacoes.size(); i++){
        if(habitacoes[i]->getId() == stoi(aux1)){
            ind = i;
            break;
        }
    }
    if(ind == -1)
        throw logic_error("Nao existe nenhuma  habitacao com o ID: "  + aux);
    std::cout << "\n\t\tPARAMETRO A ALTERAR\n\n"
              << "1) ID;\n2) Morada;\n3) Valor Base;\n4) Area Habitacional;";
    if(habitacoes[ind]->getTipo() == "Vivenda")
        std::cout << "\n5) Area Exterior;\n6) Piscina;\n7) Pago;\n8) Disponivel;";
    else
        std::cout << "\n5) Piso;\n6) Tipologia;\n7) Pago;\n8) Disponivel;";
    int param = Opcao(false, 8);
    cin.ignore(1000, '\n');
    if (habitacoes[ind]->getTipo() == "Vivenda") {
        Vivenda* v = dynamic_cast<Vivenda*> (habitacoes[ind]);
        switch (param) {
            case 1:
                std::cout << "Introduza o novo ID: ", getline(std::cin, aux);
                verifyId(stoi(aux));
                (*v).setId(aux);
                break;
            case 2:
                std::cout << "\nIntroduza a nova Morada: ", getline(std::cin, aux);
                (*v).setMorada(aux);
                break;
            case 3:
                std::cout << "Introduza o novo Valor Base: ", getline(std::cin, aux);
                (*v).setValorBase(aux);
                break;
            case 4:
                std::cout << "Introduza a nova Area Habitacional: ", getline(std::cin, aux);
                (*v).setAreaHabitacional(aux);
                break;
            case 5:
                std::cout << "Introduza a nova Area Exterior: ", getline(std::cin, aux);
                (*v).setAreaExterior(aux);
                break;
            case 6:
                std::cout << "Introduza tem Piscina?('sim'\\'nao'): ", getline(std::cin, aux);
                (*v).setPiscina(aux);
                break;
            case 7:
                std::cout << "Introduza esta Pago?('sim'\\'nao'): ", getline(std::cin, aux);
                (*v).setPago(aux);
                break;
            case 8:
                std::cout << "Introduza esta Disponivel('sim'\\'nao'): ", getline(std::cin, aux);
                (*v).setDisponibilidade(aux);
                break;
        }
    }
    else {
        Apartamento* a = dynamic_cast<Apartamento*> (habitacoes[ind]);
        switch (param) {
            case 1:
                std::cout << "Introduza o novo ID: ", getline(std::cin, aux);
                verifyId(stoi(aux));
                (*a).setId(aux);
                break;
            case 2:
                std::cout << "\nIntroduza a nova Morada: ", getline(std::cin, aux);
                (*a).setMorada(aux);
                break;
            case 3:
                std::cout << "Introduza o novo Valor Base: ", getline(std::cin, aux);
                (*a).setValorBase(aux);
                break;
            case 4:
                std::cout << "Introduza a nova Area Habitacional: ", getline(std::cin, aux);
                (*a).setAreaHabitacional(aux);
                break;
            case 5:
                std::cout << "Introduza o novo Piso: ", getline(std::cin, aux);
                (*a).setPiso(aux);
                break;
            case 6:
                std::cout << "Introduza a nova Tipologia: ", getline(std::cin, aux);
                (*a).setTipologia(aux);
                break;
            case 7:
                std::cout << "Introduza esta Pago?('sim'\\'nao'): ", getline(std::cin, aux);
                (*a).setPago(aux);
                break;
            case 8:
                std::cout << "Introduza esta Disponivel('sim'\\'nao'): ", getline(std::cin, aux);
                (*a).setDisponibilidade(aux);
                break;
        }
    }
    cout << "\nHabitacao alterada com sucesso!\n\n";
    habitacoes[ind]->imprime();
}

void Condominio::removerHabitacao(){
    verTodosHabitacoes(0);
    string aux, aux1 = "";
    int onde = -1;
    cin.ignore(1000, '\n');
    cout << "Introduza o ID do pacote: ", getline(cin, aux);
    for (int i = 0; i < aux.length(); i++) {
        if (!isdigit(aux[i]) && aux[i] != ' ')
            throw logic_error("Erro no atributo ID!");
        else if(aux[i] != ' ')
            aux1 += string(1, aux[i]);
    }
    for(int i = 0; i < habitacoes.size(); i++){
        if(habitacoes[i]->getId() == stoi(aux1)){
            onde = i;
            break;
        }
    }
    if(onde == -1)
        throw logic_error("Nao existe nenhum pacote com o ID: " + aux);
    habitacoes.erase(habitacoes.begin() + onde);
    cout << "\nHabitacao removida com sucesso!";
}

void Condominio::verifyId(int id){
    for(int i = 0; i < habitacoes.size(); i++){
        if(habitacoes[i]->getId() == id)
            throw logic_error("Ja existe uma habitacao com o ID: " + id);
    }
}

void Condominio::verifyNif(string &nif){
    string aux = "";
    for (int i = 0; i < nif.length(); i++) {
        if (!isdigit(nif[i]) && nif[i] != ' ')
            throw logic_error("Erro ao no atributo Nif!");
        else if(nif[i] != ' ')
            aux += string(1, nif[i]);
    }
    if(aux.length() != 9)
        throw logic_error("O atributo nif tem de ter 9 numeros!");
    for(int i = 0; i < clientes.size(); i++){
        if(clientes[i].getNif() == stoi(aux))
            throw logic_error("Ja existe um cliente com esse NIF: " + nif);
    }
    nif = aux;
}

void Condominio::pagar(){
    imprimeTodosClientes(0);
    string aux;
    cin.ignore(1000, '\n');
    cout << "Introduza o nome do Cliente: ", getline(cin, aux);
    formataNome(aux);
    Cliente c(aux);
    vector<Cliente>::iterator it = find(clientes.begin(), clientes.end(), c);
    if(it == clientes.end())
        throw logic_error("Nao existe nenhum cliente com o nome: "  + aux);
    int id = it->pagarMen();
    for(int i = 0; i < habitacoes.size(); i++){
        if(habitacoes[i]->getId() == id){
            habitacoes[i]->setPago("sim");
            break;
        }
    }
    cout << "\nMensalidade paga com sucesso!";
}

void Condominio::imprimeApartamentos(){
    for (int i = 0; i < habitacoes.size(); i++){
       if(habitacoes[i]->getTipo() == "Apartamento")
           habitacoes[i]->imprime();
    }
}

void Condominio::imprimeVivendas(){
    for (int i = 0; i < habitacoes.size(); i++){
        if(habitacoes[i]->getTipo() == "Vivenda")
            habitacoes[i]->imprime();
    }
}

void Condominio::verLucMen() {
    double lucro = 0;
    for(int i = 0; i < habitacoes.size(); i++){
        if(habitacoes[i]->getPago() == true)
            lucro += habitacoes[i]->getMensalidade();
    }
    cout << "O Condominio lucrou com base nas Mensalidades em: " << lucro << " $!\n\n";
}

//---------------------------------------------------------
//                  AUXILIARES
//---------------------------------------------------------

int Opcao(bool zero, int num){
    int op;
    if(zero == true) {
        std::cout << "\n\nInsira a sua opcao: ", std::cin >> op;
        while (std::cin.fail() || op < 0 || op > num) {
            if (std::cin.fail()) {
                std::cin.clear();
                std::cin.ignore(1000, '\n');
            } else {
                std::cin.ignore(1000, '\n');
            }
            std::cout << "Opcao Invalida! Insira a sua opcao: ", std::cin >> op;
        }
    }
    else{
        std::cout << "\n\nInsira a sua opcao: ", std::cin >> op;
        while (std::cin.fail() || op < 1 || op > num) {
            if (std::cin.fail()) {
                std::cin.clear();
                std::cin.ignore(1000, '\n');
            } else {
                std::cin.ignore(1000, '\n');
            }
            std::cout << "Opcao Invalida! Insira a sua opcao: ", std::cin >> op;
        }
    }
    return op;
}



