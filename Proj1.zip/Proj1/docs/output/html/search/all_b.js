var searchData=
[
  ['setareaexterior_31',['setAreaExterior',['../class_vivenda.html#a3c22425ee0eb73da65bf3fca47461098',1,'Vivenda']]],
  ['setids_32',['setIds',['../class_cliente.html#ad3af4ba889d04dce246b60b8c5824b57',1,'Cliente']]],
  ['setnif_33',['setNif',['../class_cliente.html#a352e32323cdd1e0be387d4a01c7c0234',1,'Cliente']]],
  ['setnome_34',['setNome',['../class_cliente.html#ac1bc94d2426b7d4c5b33705963d05950',1,'Cliente']]],
  ['setpiscina_35',['setPiscina',['../class_vivenda.html#a43b329e34628bdfa838df8114f1439cf',1,'Vivenda']]],
  ['setpiso_36',['setPiso',['../class_apartamento.html#a7734dad130b9688007b1467adce5b870',1,'Apartamento']]],
  ['settipologia_37',['setTipologia',['../class_apartamento.html#ae2e2f266a7545259299099c9c944ee72',1,'Apartamento']]]
];
