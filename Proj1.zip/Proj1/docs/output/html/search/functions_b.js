var searchData=
[
  ['servicos_189',['Servicos',['../class_servicos.html#a2dd03511fdd7000baa348399db25953f',1,'Servicos::Servicos()'],['../class_servicos.html#aaf807bdf85e30f78bce93b55d187de22',1,'Servicos::Servicos(string servico, string prestador, float preco_mensal)']]],
  ['setareaexterior_190',['setAreaExterior',['../class_vivenda.html#a3c22425ee0eb73da65bf3fca47461098',1,'Vivenda']]],
  ['setareahabitacional_191',['setAreaHabitacional',['../class_habitacao.html#abd7e93e315de8a28f253775e654eefec',1,'Habitacao']]],
  ['setdisponibilidade_192',['setdisponibilidade',['../class_servicos.html#af030f7bea3ca65f151e4b2b1e514aa40',1,'Servicos::setdisponibilidade()'],['../class_habitacao.html#a9157fa641f74bf3c698b0f5f9698fac2',1,'Habitacao::setDisponibilidade()']]],
  ['setid_193',['setId',['../class_habitacao.html#aeba7c71250a70c288b54a05364f77c3d',1,'Habitacao']]],
  ['setids_194',['setIds',['../class_cliente.html#ad3af4ba889d04dce246b60b8c5824b57',1,'Cliente']]],
  ['setmorada_195',['setMorada',['../class_habitacao.html#a500d458aa202caf0b57ac8716b31989b',1,'Habitacao']]],
  ['setnif_196',['setNif',['../class_cliente.html#a352e32323cdd1e0be387d4a01c7c0234',1,'Cliente']]],
  ['setnome_197',['setNome',['../class_cliente.html#ac1bc94d2426b7d4c5b33705963d05950',1,'Cliente']]],
  ['setnumocorrencias_198',['setnumOcorrencias',['../class_servicos.html#a27f6cc201936a2538bad0003872b326c',1,'Servicos']]],
  ['setpago_199',['setPago',['../class_habitacao.html#a84227c32e566cd97b8bd903033d290a6',1,'Habitacao']]],
  ['setpiscina_200',['setPiscina',['../class_vivenda.html#a43b329e34628bdfa838df8114f1439cf',1,'Vivenda']]],
  ['setpiso_201',['setPiso',['../class_apartamento.html#a7734dad130b9688007b1467adce5b870',1,'Apartamento']]],
  ['setprecomensal_202',['setprecomensal',['../class_servicos.html#ac05c923d41ffe1ddd1af71485ed24a87',1,'Servicos::setprecomensal(string preco)'],['../class_servicos.html#a4c053de69a27c1868c4a1f54fe2f66a3',1,'Servicos::setprecomensal(float preco)']]],
  ['setprestador_203',['setprestador',['../class_servicos.html#a1e9f9025fbef6b78afcd190f22069607',1,'Servicos']]],
  ['setproprietario_204',['setProprietario',['../class_habitacao.html#ae7d1126aa892420a79ad4bcbc8467715',1,'Habitacao']]],
  ['setservico_205',['setservico',['../class_servicos.html#ac9bbd9c9d9858a7395d8114a4821fdb3',1,'Servicos']]],
  ['settipo_206',['setTipo',['../class_habitacao.html#af1e78da6967d32dde4958ccbb777e447',1,'Habitacao']]],
  ['settipologia_207',['setTipologia',['../class_apartamento.html#ae2e2f266a7545259299099c9c944ee72',1,'Apartamento']]],
  ['setvalorbase_208',['setValorBase',['../class_habitacao.html#a8820eec6d260c4b37289be9b4a8d2c45',1,'Habitacao']]],
  ['startservico_209',['startservico',['../class_servicos.html#a4d41ccd7c66f9e78766399afdb1a6fc0',1,'Servicos']]]
];
