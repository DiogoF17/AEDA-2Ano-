var searchData=
[
  ['calcimposto_56',['calcImposto',['../class_vivenda.html#af525930bd8b6c55a947d2b5166a0402f',1,'Vivenda::calcImposto()'],['../class_apartamento.html#a692aa1095c13d047a24f832c3582067d',1,'Apartamento::calcImposto()']]],
  ['cliente_57',['Cliente',['../class_cliente.html#a8806bd4675e77f1f77ec2a1ba27ee2b8',1,'Cliente']]]
];
