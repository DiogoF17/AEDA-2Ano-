var indexSectionsWithContent =
{
  0: "acdeghinoprsuvw~",
  1: "acv",
  2: "acdegioprsvw~",
  3: "chnu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables"
};

