var searchData=
[
  ['setareaexterior_57',['setAreaExterior',['../class_vivenda.html#a3c22425ee0eb73da65bf3fca47461098',1,'Vivenda']]],
  ['setareahabitacional_58',['setAreaHabitacional',['../class_habitacao.html#abd7e93e315de8a28f253775e654eefec',1,'Habitacao']]],
  ['setdisponibilidade_59',['setDisponibilidade',['../class_habitacao.html#a9157fa641f74bf3c698b0f5f9698fac2',1,'Habitacao']]],
  ['setid_60',['setId',['../class_habitacao.html#aeba7c71250a70c288b54a05364f77c3d',1,'Habitacao']]],
  ['setids_61',['setIds',['../class_cliente.html#ad3af4ba889d04dce246b60b8c5824b57',1,'Cliente']]],
  ['setmorada_62',['setMorada',['../class_habitacao.html#a500d458aa202caf0b57ac8716b31989b',1,'Habitacao']]],
  ['setnif_63',['setNif',['../class_cliente.html#a352e32323cdd1e0be387d4a01c7c0234',1,'Cliente']]],
  ['setnome_64',['setNome',['../class_cliente.html#ac1bc94d2426b7d4c5b33705963d05950',1,'Cliente']]],
  ['setpago_65',['setPago',['../class_habitacao.html#a84227c32e566cd97b8bd903033d290a6',1,'Habitacao']]],
  ['setpiscina_66',['setPiscina',['../class_vivenda.html#a43b329e34628bdfa838df8114f1439cf',1,'Vivenda']]],
  ['setpiso_67',['setPiso',['../class_apartamento.html#a7734dad130b9688007b1467adce5b870',1,'Apartamento']]],
  ['setproprietario_68',['setProprietario',['../class_habitacao.html#ae7d1126aa892420a79ad4bcbc8467715',1,'Habitacao']]],
  ['settipo_69',['setTipo',['../class_habitacao.html#af1e78da6967d32dde4958ccbb777e447',1,'Habitacao']]],
  ['settipologia_70',['setTipologia',['../class_apartamento.html#ae2e2f266a7545259299099c9c944ee72',1,'Apartamento']]],
  ['setvalorbase_71',['setValorBase',['../class_habitacao.html#a8820eec6d260c4b37289be9b4a8d2c45',1,'Habitacao']]]
];
