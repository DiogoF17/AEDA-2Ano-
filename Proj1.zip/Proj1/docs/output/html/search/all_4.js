var searchData=
[
  ['getareaexterior_13',['getAreaExterior',['../class_vivenda.html#a3f6a3bf4e000e30ba94ae17fed43c4e3',1,'Vivenda']]],
  ['getids_14',['getIds',['../class_cliente.html#a9b92db20d77581a11143516642b33e4f',1,'Cliente']]],
  ['getnif_15',['getNif',['../class_cliente.html#ae7314e28d6a22b770f2d20695222e2d9',1,'Cliente']]],
  ['getnome_16',['getNome',['../class_cliente.html#aafbd233488a7e6f4e297b58cabb654bb',1,'Cliente']]],
  ['getpiscina_17',['getPiscina',['../class_vivenda.html#aff2cde9d3d445366e7d939d234025ede',1,'Vivenda']]],
  ['getpiso_18',['getPiso',['../class_apartamento.html#a8e91a807b69b2fe3e1a11f4cd4739279',1,'Apartamento']]],
  ['gettipologia_19',['getTipologia',['../class_apartamento.html#ab7940f4635d4ca7c6f760245847d0ecb',1,'Apartamento']]]
];
