var searchData=
[
  ['tipo_72',['tipo',['../class_habitacao.html#a227535d1f640642000409a4d2a06961a',1,'Habitacao']]],
  ['tipologia_73',['tipologia',['../class_apartamento.html#a0081643fda34c297b79062fc6cbd7bf9',1,'Apartamento']]]
];
