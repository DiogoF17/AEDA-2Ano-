var searchData=
[
  ['habitacoes_91',['habitacoes',['../class_condominio.html#a22329242291d2e4c81333a68f6346f27',1,'Condominio']]]
];
