var searchData=
[
  ['nomeficheiro_92',['nomeFicheiro',['../class_condominio.html#ad6061cfb17a7efbb9b5cf03395963c13',1,'Condominio']]]
];
