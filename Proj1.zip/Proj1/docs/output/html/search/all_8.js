var searchData=
[
  ['operator_3d_3d_25',['operator==',['../class_cliente.html#ad18df5bc5519b81b1967ce8992d7d947',1,'Cliente']]]
];
